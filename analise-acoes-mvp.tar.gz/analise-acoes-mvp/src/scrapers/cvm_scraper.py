"""
Scraper da CVM para dados fundamentalistas
NOTA: Versão simplificada para MVP
Para produção, implementar parser completo de XBRL/DFP
"""
import requests
from bs4 import BeautifulSoup
import logging
from typing import Dict, List, Optional
from datetime import datetime
import random

logger = logging.getLogger(__name__)


class CVMScraper:
    """
    Scraper para dados da CVM
    
    NOTA MVP: Por limitações de tempo, esta versão usa dados simulados
    baseados em médias históricas do setor.
    
    Para produção completa, implementar:
    1. Download de arquivos DFP/ITR do site da CVM
    2. Parse de XML/XBRL
    3. Extração de demonstrativos financeiros completos
    """
    
    BASE_URL = "https://www.rad.cvm.gov.br/ENET/"
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def get_financial_data(self, ticker: str, cnpj: Optional[str] = None) -> List[Dict]:
        """
        Busca dados fundamentalistas
        
        Args:
            ticker: Código da ação
            cnpj: CNPJ da empresa (opcional)
        
        Returns:
            Lista de demonstrativos financeiros
        """
        logger.info(f"Buscando dados CVM para {ticker}...")
        
        # NOTA MVP: Retornando dados simulados baseados em padrões setoriais
        # Na versão completa, fazer scraping real da CVM
        
        return self._generate_mock_financials(ticker)
    
    def _generate_mock_financials(self, ticker: str) -> List[Dict]:
        """
        Gera dados financeiros simulados para MVP
        
        Baseado em médias históricas do setor
        """
        base_revenue = self._get_base_revenue_by_ticker(ticker)
        financials = []
        
        # Últimos 20 trimestres (5 anos)
        for i in range(20):
            quarter = 20 - i
            year = 2021 + (quarter // 4)
            q = (quarter % 4) + 1
            
            # Crescimento aleatório entre -10% e +15%
            growth_factor = 1 + random.uniform(-0.10, 0.15)
            revenue = base_revenue * growth_factor * (1 + i * 0.02)
            
            # Margens típicas
            gross_margin = random.uniform(0.25, 0.40)
            operating_margin = random.uniform(0.10, 0.25)
            net_margin = random.uniform(0.05, 0.20)
            
            financials.append({
                'ticker': ticker,
                'period': datetime(year, q*3, 1).date(),
                'period_type': 'Q',
                'revenue': revenue,
                'gross_profit': revenue * gross_margin,
                'operating_income': revenue * operating_margin,
                'net_income': revenue * net_margin,
                'ebitda': revenue * (operating_margin + 0.05),
                'total_assets': revenue * 3.5,
                'total_liabilities': revenue * 2.0,
                'shareholders_equity': revenue * 1.5
            })
        
        return financials
    
    def _get_base_revenue_by_ticker(self, ticker: str) -> float:
        """
        Retorna receita base estimada por ticker
        Valores em milhões de R$
        """
        # Grandes empresas
        large_caps = {
            'PETR4': 120000, 'VALE3': 85000, 'ITUB4': 65000,
            'BBDC4': 55000, 'BBAS3': 60000, 'ABEV3': 18000
        }
        
        # Médias empresas
        mid_caps = {
            'WEGE3': 6000, 'RENT3': 4500, 'RADL3': 8000,
            'HAPV3': 7500, 'SUZB3': 12000
        }
        
        # Pequenas empresas
        if ticker in large_caps:
            return large_caps[ticker] / 4  # Por trimestre
        elif ticker in mid_caps:
            return mid_caps[ticker] / 4
        else:
            return random.uniform(500, 2000)  # Estimativa genérica


def test_cvm_scraper():
    """Teste do scraper CVM"""
    scraper = CVMScraper()
    
    print("=== Teste CVM Scraper ===\n")
    
    # Teste com PETR4
    print("Buscando dados da PETR4...")
    financials = scraper.get_financial_data("PETR4")
    
    if financials:
        print(f"Total de registros: {len(financials)}")
        print(f"\nÚltimo trimestre:")
        last = financials[-1]
        print(f"  Período: {last['period']}")
        print(f"  Receita: R$ {last['revenue']:,.2f}M")
        print(f"  Lucro Líquido: R$ {last['net_income']:,.2f}M")
        print(f"  Margem Líquida: {(last['net_income']/last['revenue']*100):.2f}%")
    
    print("\n✅ Teste concluído!")
    print("\n⚠️  NOTA: Dados simulados para MVP")
    print("Para produção, implementar scraping real da CVM")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    test_cvm_scraper()
