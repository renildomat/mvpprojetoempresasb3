"""
Módulo de scrapers de dados
"""
from src.scrapers.yahoo_finance import (
    get_b3_tickers,
    fetch_stock_info,
    fetch_stock_prices,
    fetch_latest_price,
    fetch_all_stocks_data
)
from src.scrapers.cvm_scraper import CVMScraper
from src.scrapers.bacen_api import BacenAPI

__all__ = [
    'get_b3_tickers',
    'fetch_stock_info',
    'fetch_stock_prices',
    'fetch_latest_price',
    'fetch_all_stocks_data',
    'CVMScraper',
    'BacenAPI'
]
