"""
Scraper de cotações do Yahoo Finance
"""
import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import logging

logger = logging.getLogger(__name__)


def get_b3_tickers() -> List[str]:
    """
    Retorna lista de tickers da B3
    
    Nota: Para MVP, usando lista fixa das principais ações
    Futuramente pode ser expandido para buscar dinamicamente
    """
    # Top ~50 ações mais líquidas da B3
    tickers = [
        "PETR4", "VALE3", "ITUB4", "BBDC4", "ABEV3", "BBAS3", "WEGE3", 
        "B3SA3", "RENT3", "SUZB3", "ELET3", "ELET6", "RAIL3", "PRIO3",
        "HAPV3", "RADL3", "JBSS3", "EMBR3", "GGBR4", "CSNA3", "GOAU4",
        "USIM5", "CSAN3", "KLBN11", "BRFS3", "EQTL3", "CMIG4", "CPLE6",
        "ENBR3", "TAEE11", "CMIN3", "TRPL4", "FLRY3", "VIVT3", "TIMP3",
        "MGLU3", "ASAI3", "LWSA3", "CASH3", "ARZZ3", "SOMA3", "PETZ3",
        "ALOS3", "SBSP3", "SAPR11", "CXSE3", "ENGI11", "NEOE3", "CPFE3",
        "VAMO3"
    ]
    return tickers


def fetch_stock_info(ticker: str) -> Optional[Dict]:
    """
    Busca informações básicas da ação
    
    Args:
        ticker: Código da ação (sem .SA)
    
    Returns:
        Dicionário com informações ou None se falhar
    """
    try:
        stock = yf.Ticker(f"{ticker}.SA")
        info = stock.info
        
        return {
            'ticker': ticker,
            'company_name': info.get('longName', ticker),
            'sector': info.get('sector', 'N/A'),
            'subsector': info.get('industry', 'N/A'),
            'market_cap': info.get('marketCap', 0),
            'average_volume': info.get('averageVolume', 0)
        }
    except Exception as e:
        logger.error(f"Erro ao buscar info de {ticker}: {e}")
        return None


def fetch_stock_prices(ticker: str, period: str = "5y", interval: str = "1d") -> List[Dict]:
    """
    Busca preços históricos do Yahoo Finance
    
    Args:
        ticker: Código da ação (sem .SA)
        period: Período (1d, 5d, 1mo, 3mo, 6mo, 1y, 2y, 5y, 10y, ytd, max)
        interval: Intervalo (1m, 2m, 5m, 15m, 30m, 60m, 90m, 1h, 1d, 5d, 1wk, 1mo, 3mo)
    
    Returns:
        Lista de dicionários com preços
    """
    try:
        stock = yf.Ticker(f"{ticker}.SA")
        df = stock.history(period=period, interval=interval)
        
        if df.empty:
            logger.warning(f"Nenhum dado encontrado para {ticker}")
            return []
        
        prices = []
        for date, row in df.iterrows():
            prices.append({
                'ticker': ticker,
                'date': date.date(),
                'open': float(row['Open']) if pd.notna(row['Open']) else None,
                'high': float(row['High']) if pd.notna(row['High']) else None,
                'low': float(row['Low']) if pd.notna(row['Low']) else None,
                'close': float(row['Close']) if pd.notna(row['Close']) else None,
                'volume': int(row['Volume']) if pd.notna(row['Volume']) else None
            })
        
        logger.info(f"✅ {ticker}: {len(prices)} registros de preços coletados")
        return prices
        
    except Exception as e:
        logger.error(f"Erro ao buscar preços de {ticker}: {e}")
        return []


def fetch_latest_price(ticker: str) -> Optional[Dict]:
    """
    Busca apenas o preço mais recente
    
    Args:
        ticker: Código da ação (sem .SA)
    
    Returns:
        Dicionário com último preço ou None
    """
    prices = fetch_stock_prices(ticker, period="5d", interval="1d")
    return prices[-1] if prices else None


def fetch_all_stocks_data(tickers: Optional[List[str]] = None) -> Dict[str, Dict]:
    """
    Busca dados de múltiplas ações
    
    Args:
        tickers: Lista de tickers. Se None, usa get_b3_tickers()
    
    Returns:
        Dicionário {ticker: {'info': {...}, 'prices': [...]}}
    """
    if tickers is None:
        tickers = get_b3_tickers()
    
    results = {}
    total = len(tickers)
    
    for i, ticker in enumerate(tickers, 1):
        logger.info(f"Processando {ticker} ({i}/{total})...")
        
        info = fetch_stock_info(ticker)
        prices = fetch_stock_prices(ticker)
        
        results[ticker] = {
            'info': info,
            'prices': prices
        }
    
    logger.info(f"✅ Dados coletados de {len(results)} ações")
    return results


if __name__ == "__main__":
    # Teste do módulo
    logging.basicConfig(level=logging.INFO)
    
    print("=== Teste do Yahoo Finance Scraper ===\n")
    
    # Teste 1: Buscar informações de uma ação
    print("1. Buscando informações da PETR4...")
    info = fetch_stock_info("PETR4")
    if info:
        print(f"   Nome: {info['company_name']}")
        print(f"   Setor: {info['sector']}")
        print(f"   Market Cap: R$ {info['market_cap']:,.0f}\n")
    
    # Teste 2: Buscar preços históricos
    print("2. Buscando preços históricos da PETR4 (últimos 30 dias)...")
    prices = fetch_stock_prices("PETR4", period="1mo")
    if prices:
        print(f"   Total de registros: {len(prices)}")
        print(f"   Primeiro: {prices[0]['date']} - R$ {prices[0]['close']:.2f}")
        print(f"   Último: {prices[-1]['date']} - R$ {prices[-1]['close']:.2f}\n")
    
    # Teste 3: Preço mais recente
    print("3. Buscando último preço da VALE3...")
    latest = fetch_latest_price("VALE3")
    if latest:
        print(f"   Data: {latest['date']}")
        print(f"   Fechamento: R$ {latest['close']:.2f}")
        print(f"   Volume: {latest['volume']:,}\n")
    
    print("✅ Testes concluídos!")
