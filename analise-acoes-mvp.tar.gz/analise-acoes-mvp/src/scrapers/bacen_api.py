"""
Cliente para API do Banco Central do Brasil
Dados macroeconômicos (Selic, IPCA, Câmbio, etc.)
"""
import requests
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)


class BacenAPI:
    """
    Cliente para API de Dados Abertos do Banco Central
    Documentação: https://dadosabertos.bcb.gov.br/
    """
    
    BASE_URL = "https://api.bcb.gov.br/dados/serie/bcdata.sgs.{}/dados"
    
    # Códigos das séries temporais
    SERIES = {
        'SELIC': 432,           # Taxa Selic
        'IPCA': 433,            # IPCA
        'IGP_M': 189,           # IGP-M
        'USD': 1,               # Dólar (PTAX venda)
        'EUR': 21619,           # Euro (PTAX venda)
        'PIB': 4380,            # PIB mensal
        'PRODUCAO_INDUSTRIAL': 21859  # Produção industrial
    }
    
    def __init__(self):
        self.session = requests.Session()
    
    def get_series(
        self,
        series_name: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[Dict]:
        """
        Busca série temporal do BCB
        
        Args:
            series_name: Nome da série (chave do dict SERIES)
            start_date: Data inicial (dd/mm/yyyy)
            end_date: Data final (dd/mm/yyyy)
        
        Returns:
            Lista de dicionários com data e valor
        """
        if series_name not in self.SERIES:
            logger.error(f"Série '{series_name}' não encontrada")
            return []
        
        series_code = self.SERIES[series_name]
        
        # Construir URL
        url = self.BASE_URL.format(series_code)
        params = {}
        
        if start_date:
            params['dataInicial'] = start_date
        if end_date:
            params['dataFinal'] = end_date
        
        try:
            response = self.session.get(url, params=params, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            
            # Formatar resposta
            result = []
            for item in data:
                result.append({
                    'date': datetime.strptime(item['data'], '%d/%m/%Y').date(),
                    'value': float(item['valor'])
                })
            
            logger.info(f"✅ {series_name}: {len(result)} registros obtidos")
            return result
            
        except Exception as e:
            logger.error(f"Erro ao buscar série {series_name}: {e}")
            return []
    
    def get_latest_value(self, series_name: str) -> Optional[float]:
        """
        Retorna o valor mais recente de uma série
        
        Args:
            series_name: Nome da série
        
        Returns:
            Valor mais recente ou None
        """
        # Buscar últimos 30 dias
        end_date = datetime.now()
        start_date = end_date - timedelta(days=30)
        
        data = self.get_series(
            series_name,
            start_date.strftime('%d/%m/%Y'),
            end_date.strftime('%d/%m/%Y')
        )
        
        return data[-1]['value'] if data else None
    
    def get_selic(self) -> Optional[float]:
        """Retorna taxa Selic atual (% a.a.)"""
        return self.get_latest_value('SELIC')
    
    def get_ipca(self) -> Optional[float]:
        """Retorna IPCA mais recente (%)"""
        return self.get_latest_value('IPCA')
    
    def get_usd_rate(self) -> Optional[float]:
        """Retorna cotação do dólar (PTAX)"""
        return self.get_latest_value('USD')
    
    def get_all_indicators(self) -> Dict[str, float]:
        """
        Retorna todos os principais indicadores
        
        Returns:
            Dicionário com indicadores atuais
        """
        return {
            'selic': self.get_selic() or 0,
            'ipca': self.get_ipca() or 0,
            'usd': self.get_usd_rate() or 0
        }


def test_bacen_api():
    """Teste da API do Banco Central"""
    api = BacenAPI()
    
    print("=== Teste Bacen API ===\n")
    
    # Teste 1: Taxa Selic
    print("1. Buscando Taxa Selic atual...")
    selic = api.get_selic()
    if selic:
        print(f"   Selic: {selic:.2f}% a.a.\n")
    
    # Teste 2: IPCA
    print("2. Buscando IPCA...")
    ipca = api.get_ipca()
    if ipca:
        print(f"   IPCA: {ipca:.2f}%\n")
    
    # Teste 3: Dólar
    print("3. Buscando cotação do Dólar...")
    usd = api.get_usd_rate()
    if usd:
        print(f"   USD: R$ {usd:.4f}\n")
    
    # Teste 4: Todos indicadores
    print("4. Buscando todos indicadores...")
    indicators = api.get_all_indicators()
    print(f"   {indicators}\n")
    
    # Teste 5: Série histórica
    print("5. Buscando histórico do dólar (últimos 30 dias)...")
    end_date = datetime.now()
    start_date = end_date - timedelta(days=30)
    
    usd_history = api.get_series(
        'USD',
        start_date.strftime('%d/%m/%Y'),
        end_date.strftime('%d/%m/%Y')
    )
    
    if usd_history:
        print(f"   Total de registros: {len(usd_history)}")
        print(f"   Primeiro: {usd_history[0]['date']} = R$ {usd_history[0]['value']:.4f}")
        print(f"   Último: {usd_history[-1]['date']} = R$ {usd_history[-1]['value']:.4f}")
    
    print("\n✅ Testes concluídos!")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    test_bacen_api()
