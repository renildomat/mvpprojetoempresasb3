"""
Scheduler para execução automática de jobs
Usa APScheduler para agendar tarefas em background
"""
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from datetime import datetime
import logging
import atexit

from src.jobs.tasks import JobRunner

logger = logging.getLogger(__name__)


class JobScheduler:
    """
    Gerenciador de jobs automatizados
    
    Schedule:
    - 19h diariamente: Atualizar cotações
    - 20h diariamente: Calcular scores
    - Domingos 2h: Atualizar dados CVM
    - 3h diariamente: Backup (futuro)
    """
    
    def __init__(self):
        self.scheduler = BackgroundScheduler()
        self.runner = JobRunner()
        self.is_running = False
    
    def start(self):
        """Inicia o scheduler com todos os jobs configurados"""
        if self.is_running:
            logger.warning("⚠️  Scheduler já está rodando")
            return
        
        logger.info("🚀 Configurando jobs automatizados...")
        
        # Job 1: Atualizar cotações (todo dia às 19h)
        self.scheduler.add_job(
            func=self.runner.update_stock_prices,
            trigger=CronTrigger(hour=19, minute=0),
            id='update_prices',
            name='Atualizar Cotações',
            replace_existing=True,
            max_instances=1  # Evitar execuções concorrentes
        )
        logger.info("  ✅ Job 'Atualizar Cotações' agendado para 19h diariamente")
        
        # Job 2: Calcular scores (todo dia às 20h)
        self.scheduler.add_job(
            func=self.runner.calculate_opportunity_scores,
            trigger=CronTrigger(hour=20, minute=0),
            id='calculate_scores',
            name='Calcular Scores',
            replace_existing=True,
            max_instances=1
        )
        logger.info("  ✅ Job 'Calcular Scores' agendado para 20h diariamente")
        
        # Job 3: Atualizar dados CVM (domingos às 2h)
        self.scheduler.add_job(
            func=self.runner.update_cvm_data,
            trigger=CronTrigger(day_of_week='sun', hour=2, minute=0),
            id='update_cvm',
            name='Atualizar Dados CVM',
            replace_existing=True,
            max_instances=1
        )
        logger.info("  ✅ Job 'Atualizar CVM' agendado para Domingos 2h")
        
        # Iniciar scheduler
        self.scheduler.start()
        self.is_running = True
        
        logger.info("✅ Scheduler iniciado com sucesso!")
        logger.info("📋 Próximas execuções:")
        self._print_next_runs()
        
        # Registrar shutdown automático
        atexit.register(self.shutdown)
    
    def run_job_now(self, job_id: str):
        """
        Executa um job imediatamente (fora do schedule)
        
        Args:
            job_id: ID do job ('update_prices', 'calculate_scores', 'update_cvm')
        """
        job_map = {
            'update_prices': self.runner.update_stock_prices,
            'calculate_scores': self.runner.calculate_opportunity_scores,
            'update_cvm': self.runner.update_cvm_data,
            'update_stocks': self.runner.update_stocks_info
        }
        
        if job_id not in job_map:
            logger.error(f"❌ Job '{job_id}' não encontrado")
            return
        
        logger.info(f"🚀 Executando job '{job_id}' manualmente...")
        try:
            job_map[job_id]()
            logger.info(f"✅ Job '{job_id}' concluído")
        except Exception as e:
            logger.error(f"❌ Erro ao executar job '{job_id}': {e}")
    
    def get_jobs_status(self):
        """
        Retorna status de todos os jobs
        
        Returns:
            Lista de dicionários com info dos jobs
        """
        jobs_info = []
        
        for job in self.scheduler.get_jobs():
            next_run = job.next_run_time
            jobs_info.append({
                'id': job.id,
                'name': job.name,
                'next_run': next_run.strftime('%Y-%m-%d %H:%M:%S') if next_run else 'N/A',
                'pending': next_run is not None
            })
        
        return jobs_info
    
    def _print_next_runs(self):
        """Imprime próximas execuções dos jobs"""
        for job_info in self.get_jobs_status():
            logger.info(f"  • {job_info['name']}: {job_info['next_run']}")
    
    def shutdown(self):
        """Desliga o scheduler gracefully"""
        if not self.is_running:
            return
        
        logger.info("🛑 Desligando scheduler...")
        self.scheduler.shutdown(wait=True)
        self.is_running = False
        logger.info("✅ Scheduler desligado")
    
    def pause_job(self, job_id: str):
        """Pausa um job específico"""
        self.scheduler.pause_job(job_id)
        logger.info(f"⏸️  Job '{job_id}' pausado")
    
    def resume_job(self, job_id: str):
        """Resume um job pausado"""
        self.scheduler.resume_job(job_id)
        logger.info(f"▶️  Job '{job_id}' resumido")


# Instância global do scheduler
_global_scheduler = None


def get_scheduler() -> JobScheduler:
    """
    Retorna instância global do scheduler (singleton)
    """
    global _global_scheduler
    if _global_scheduler is None:
        _global_scheduler = JobScheduler()
    return _global_scheduler


def start_scheduler():
    """Inicia o scheduler global"""
    scheduler = get_scheduler()
    if not scheduler.is_running:
        scheduler.start()
    return scheduler


if __name__ == "__main__":
    # Teste do scheduler
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print("=== Teste do Scheduler ===\n")
    
    # Inicializar banco
    from src.database import init_database
    init_database()
    
    # Criar scheduler
    scheduler = JobScheduler()
    
    # Iniciar
    scheduler.start()
    
    # Mostrar status
    print("\nStatus dos jobs:")
    for job_info in scheduler.get_jobs_status():
        print(f"  {job_info['name']}: próxima execução em {job_info['next_run']}")
    
    # Executar um job manualmente (para teste)
    print("\nExecutando job de teste manualmente...")
    scheduler.run_job_now('update_stocks')
    
    print("\n✅ Teste concluído!")
    print("⚠️  Em produção, o scheduler rodará continuamente em background")
    
    # Desligar
    scheduler.shutdown()
