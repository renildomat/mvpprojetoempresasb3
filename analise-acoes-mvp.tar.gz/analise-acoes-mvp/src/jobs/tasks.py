"""
Tasks automatizadas (jobs) para atualização de dados
"""
from datetime import datetime
import logging
import pandas as pd
from sqlalchemy.orm import Session

from src.database import get_session, Stock, StockPrice, FinancialStatement, FundamentalIndicator, OpportunityScore, JobLog
from src.scrapers import fetch_stock_info, fetch_stock_prices, get_b3_tickers, CVMScraper
from src.analysis import IndicatorCalculator, DivergenceAnalyzer, OpportunityScorer

logger = logging.getLogger(__name__)


class JobRunner:
    """Executor de jobs automatizados"""
    
    def __init__(self):
        self.calculator = IndicatorCalculator()
        self.divergence_analyzer = DivergenceAnalyzer()
        self.scorer = OpportunityScorer()
        self.cvm_scraper = CVMScraper()
    
    def log_job(self, session: Session, job_name: str, status: str, started_at: datetime, 
                records_processed: int = 0, error_message: str = None):
        """Registra execução de job no banco"""
        log = JobLog(
            job_name=job_name,
            status=status,
            started_at=started_at,
            finished_at=datetime.now(),
            records_processed=records_processed,
            error_message=error_message
        )
        session.add(log)
        session.commit()
    
    def update_stocks_info(self):
        """
        Job 1: Atualizar informações básicas das ações
        Executar: Inicial (setup) ou quando adicionar novas ações
        """
        job_name = "update_stocks_info"
        started_at = datetime.now()
        session = get_session()
        
        try:
            logger.info(f"🚀 Iniciando job: {job_name}")
            
            tickers = get_b3_tickers()
            count = 0
            
            for ticker in tickers:
                # Verificar se já existe
                existing = session.query(Stock).filter_by(ticker=ticker).first()
                
                if existing:
                    logger.debug(f"  {ticker} já existe, pulando...")
                    continue
                
                # Buscar informações
                info = fetch_stock_info(ticker)
                if not info:
                    logger.warning(f"  ⚠️  Sem dados para {ticker}")
                    continue
                
                # Criar registro
                stock = Stock(
                    ticker=info['ticker'],
                    company_name=info['company_name'],
                    sector=info['sector'],
                    subsector=info['subsector'],
                    market_cap=info['market_cap'],
                    average_volume=info['average_volume']
                )
                session.add(stock)
                count += 1
                logger.info(f"  ✅ {ticker} adicionado")
            
            session.commit()
            
            self.log_job(session, job_name, 'SUCCESS', started_at, count)
            logger.info(f"✅ Job concluído: {count} ações adicionadas")
            
        except Exception as e:
            session.rollback()
            error_msg = str(e)
            self.log_job(session, job_name, 'FAILED', started_at, 0, error_msg)
            logger.error(f"❌ Erro no job {job_name}: {error_msg}")
        
        finally:
            session.close()
    
    def update_stock_prices(self):
        """
        Job 2: Atualizar cotações
        Executar: Diariamente às 19h
        """
        job_name = "update_stock_prices"
        started_at = datetime.now()
        session = get_session()
        
        try:
            logger.info(f"🚀 Iniciando job: {job_name}")
            
            stocks = session.query(Stock).all()
            total_records = 0
            
            for stock in stocks:
                # Buscar preços (últimos 30 dias para atualização)
                prices = fetch_stock_prices(stock.ticker, period="1mo")
                
                for price_data in prices:
                    # Verificar se já existe
                    existing = session.query(StockPrice).filter_by(
                        stock_id=stock.id,
                        date=price_data['date']
                    ).first()
                    
                    if existing:
                        # Atualizar
                        existing.open = price_data['open']
                        existing.high = price_data['high']
                        existing.low = price_data['low']
                        existing.close = price_data['close']
                        existing.volume = price_data['volume']
                    else:
                        # Criar novo
                        price = StockPrice(
                            stock_id=stock.id,
                            date=price_data['date'],
                            open=price_data['open'],
                            high=price_data['high'],
                            low=price_data['low'],
                            close=price_data['close'],
                            volume=price_data['volume']
                        )
                        session.add(price)
                        total_records += 1
                
                # Commit a cada ação
                session.commit()
                logger.info(f"  ✅ {stock.ticker} atualizado")
            
            self.log_job(session, job_name, 'SUCCESS', started_at, total_records)
            logger.info(f"✅ Job concluído: {total_records} preços atualizados")
            
        except Exception as e:
            session.rollback()
            error_msg = str(e)
            self.log_job(session, job_name, 'FAILED', started_at, 0, error_msg)
            logger.error(f"❌ Erro no job {job_name}: {error_msg}")
        
        finally:
            session.close()
    
    def update_cvm_data(self):
        """
        Job 3: Atualizar dados fundamentalistas (CVM)
        Executar: Semanalmente aos domingos às 2h
        """
        job_name = "update_cvm_data"
        started_at = datetime.now()
        session = get_session()
        
        try:
            logger.info(f"🚀 Iniciando job: {job_name}")
            
            stocks = session.query(Stock).all()
            total_records = 0
            
            for stock in stocks:
                # Buscar dados CVM
                financials = self.cvm_scraper.get_financial_data(stock.ticker, stock.cnpj)
                
                for fin_data in financials:
                    # Verificar se já existe
                    existing = session.query(FinancialStatement).filter_by(
                        stock_id=stock.id,
                        period=fin_data['period'],
                        period_type=fin_data['period_type']
                    ).first()
                    
                    if existing:
                        # Atualizar
                        existing.revenue = fin_data['revenue']
                        existing.gross_profit = fin_data['gross_profit']
                        existing.operating_income = fin_data['operating_income']
                        existing.net_income = fin_data['net_income']
                        existing.ebitda = fin_data['ebitda']
                        existing.total_assets = fin_data['total_assets']
                        existing.total_liabilities = fin_data['total_liabilities']
                        existing.shareholders_equity = fin_data['shareholders_equity']
                    else:
                        # Criar novo
                        financial = FinancialStatement(
                            stock_id=stock.id,
                            period=fin_data['period'],
                            period_type=fin_data['period_type'],
                            revenue=fin_data['revenue'],
                            gross_profit=fin_data['gross_profit'],
                            operating_income=fin_data['operating_income'],
                            net_income=fin_data['net_income'],
                            ebitda=fin_data['ebitda'],
                            total_assets=fin_data['total_assets'],
                            total_liabilities=fin_data['total_liabilities'],
                            shareholders_equity=fin_data['shareholders_equity']
                        )
                        session.add(financial)
                        total_records += 1
                
                session.commit()
                logger.info(f"  ✅ {stock.ticker} - dados CVM atualizados")
            
            self.log_job(session, job_name, 'SUCCESS', started_at, total_records)
            logger.info(f"✅ Job concluído: {total_records} demonstrativos atualizados")
            
        except Exception as e:
            session.rollback()
            error_msg = str(e)
            self.log_job(session, job_name, 'FAILED', started_at, 0, error_msg)
            logger.error(f"❌ Erro no job {job_name}: {error_msg}")
        
        finally:
            session.close()
    
    def calculate_opportunity_scores(self):
        """
        Job 4: Calcular scores de oportunidade
        Executar: Diariamente às 20h (após atualização de preços)
        """
        job_name = "calculate_scores"
        started_at = datetime.now()
        session = get_session()
        
        try:
            logger.info(f"🚀 Iniciando job: {job_name}")
            
            stocks = session.query(Stock).all()
            total_records = 0
            today = datetime.now().date()
            
            for stock in stocks:
                # Buscar preços históricos
                prices_query = session.query(StockPrice).filter_by(
                    stock_id=stock.id
                ).order_by(StockPrice.date).all()
                
                if len(prices_query) < 20:
                    logger.warning(f"  ⚠️  {stock.ticker} - dados insuficientes")
                    continue
                
                prices = pd.Series(
                    [p.close for p in prices_query],
                    index=[p.date for p in prices_query]
                )
                
                # Buscar dados financeiros
                financials_query = session.query(FinancialStatement).filter_by(
                    stock_id=stock.id
                ).order_by(FinancialStatement.period).all()
                
                if len(financials_query) < 4:
                    logger.warning(f"  ⚠️  {stock.ticker} - sem dados financeiros")
                    continue
                
                earnings = pd.Series(
                    [f.net_income for f in financials_query],
                    index=[f.period for f in financials_query]
                )
                
                # Calcular indicadores
                latest_financial = financials_query[-1]
                latest_price = prices.iloc[-1]
                
                indicators = self.calculator.calculate_all_indicators(
                    price=latest_price,
                    financial_data={
                        'net_income': latest_financial.net_income,
                        'revenue': latest_financial.revenue,
                        'total_assets': latest_financial.total_assets,
                        'total_liabilities': latest_financial.total_liabilities,
                        'shareholders_equity': latest_financial.shareholders_equity,
                        'annual_dividends': 0  # Simplificado para MVP
                    }
                )
                
                # Salvar indicadores
                existing_ind = session.query(FundamentalIndicator).filter_by(
                    stock_id=stock.id,
                    date=today
                ).first()
                
                if existing_ind:
                    # Atualizar
                    existing_ind.price_earnings = indicators.get('price_earnings')
                    existing_ind.price_book = indicators.get('price_book')
                    existing_ind.roe = indicators.get('roe')
                    existing_ind.roa = indicators.get('roa')
                    existing_ind.net_margin = indicators.get('net_margin')
                    existing_ind.debt_equity = indicators.get('debt_equity')
                    existing_ind.dividend_yield = indicators.get('dividend_yield')
                else:
                    indicator = FundamentalIndicator(
                        stock_id=stock.id,
                        date=today,
                        price_earnings=indicators.get('price_earnings'),
                        price_book=indicators.get('price_book'),
                        roe=indicators.get('roe'),
                        roa=indicators.get('roa'),
                        net_margin=indicators.get('net_margin'),
                        debt_equity=indicators.get('debt_equity'),
                        dividend_yield=indicators.get('dividend_yield')
                    )
                    session.add(indicator)
                
                # Calcular score
                score_result = self.scorer.calculate_score(
                    prices=prices,
                    earnings=earnings,
                    indicators=indicators
                )
                
                # Salvar score
                existing_score = session.query(OpportunityScore).filter_by(
                    stock_id=stock.id,
                    date=today
                ).first()
                
                if existing_score:
                    # Atualizar
                    existing_score.score = int(score_result['score'])
                    existing_score.signal = score_result['signal']
                    existing_score.reasoning = score_result['reasoning']
                else:
                    score = OpportunityScore(
                        stock_id=stock.id,
                        date=today,
                        score=int(score_result['score']),
                        signal=score_result['signal'],
                        reasoning=score_result['reasoning'],
                        price_trend=0,
                        earnings_trend=0,
                        divergence_magnitude=0
                    )
                    session.add(score)
                
                session.commit()
                total_records += 1
                logger.info(f"  ✅ {stock.ticker} - Score: {score_result['score']:.0f} ({score_result['signal']})")
            
            self.log_job(session, job_name, 'SUCCESS', started_at, total_records)
            logger.info(f"✅ Job concluído: {total_records} scores calculados")
            
        except Exception as e:
            session.rollback()
            error_msg = str(e)
            self.log_job(session, job_name, 'FAILED', started_at, 0, error_msg)
            logger.error(f"❌ Erro no job {job_name}: {error_msg}")
        
        finally:
            session.close()


if __name__ == "__main__":
    # Teste dos jobs
    logging.basicConfig(level=logging.INFO)
    
    runner = JobRunner()
    
    print("=== Teste de Jobs ===\n")
    
    # Inicializar banco
    from src.database import init_database
    init_database()
    
    # Job 1: Atualizar informações de ações
    print("1. Atualizando informações de ações...")
    runner.update_stocks_info()
    
    # Job 2: Atualizar preços (apenas algumas ações para teste)
    print("\n2. Atualizando preços...")
    runner.update_stock_prices()
    
    print("\n✅ Testes concluídos!")
