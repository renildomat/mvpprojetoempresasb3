"""
Cálculo de indicadores fundamentalistas
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Optional
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class IndicatorCalculator:
    """Calculadora de indicadores fundamentalistas"""
    
    @staticmethod
    def calculate_price_earnings(price: float, earnings_per_share: float) -> Optional[float]:
        """
        Calcula P/L (Price to Earnings)
        
        Args:
            price: Preço da ação
            earnings_per_share: Lucro por ação
        
        Returns:
            P/L ou None se inválido
        """
        if earnings_per_share == 0 or earnings_per_share is None:
            return None
        return price / earnings_per_share
    
    @staticmethod
    def calculate_price_book(price: float, book_value_per_share: float) -> Optional[float]:
        """
        Calcula P/VP (Price to Book Value)
        
        Args:
            price: Preço da ação
            book_value_per_share: Valor patrimonial por ação
        
        Returns:
            P/VP ou None se inválido
        """
        if book_value_per_share == 0 or book_value_per_share is None:
            return None
        return price / book_value_per_share
    
    @staticmethod
    def calculate_roe(net_income: float, shareholders_equity: float) -> Optional[float]:
        """
        Calcula ROE (Return on Equity)
        
        Args:
            net_income: Lucro líquido
            shareholders_equity: Patrimônio líquido
        
        Returns:
            ROE (em decimal, ex: 0.15 = 15%) ou None
        """
        if shareholders_equity == 0 or shareholders_equity is None:
            return None
        return net_income / shareholders_equity
    
    @staticmethod
    def calculate_roa(net_income: float, total_assets: float) -> Optional[float]:
        """
        Calcula ROA (Return on Assets)
        
        Args:
            net_income: Lucro líquido
            total_assets: Ativos totais
        
        Returns:
            ROA (em decimal) ou None
        """
        if total_assets == 0 or total_assets is None:
            return None
        return net_income / total_assets
    
    @staticmethod
    def calculate_net_margin(net_income: float, revenue: float) -> Optional[float]:
        """
        Calcula Margem Líquida
        
        Args:
            net_income: Lucro líquido
            revenue: Receita líquida
        
        Returns:
            Margem líquida (em decimal) ou None
        """
        if revenue == 0 or revenue is None:
            return None
        return net_income / revenue
    
    @staticmethod
    def calculate_debt_equity(total_liabilities: float, shareholders_equity: float) -> Optional[float]:
        """
        Calcula Dívida/Patrimônio (Debt to Equity)
        
        Args:
            total_liabilities: Passivo total
            shareholders_equity: Patrimônio líquido
        
        Returns:
            D/E ratio ou None
        """
        if shareholders_equity == 0 or shareholders_equity is None:
            return None
        return total_liabilities / shareholders_equity
    
    @staticmethod
    def calculate_dividend_yield(annual_dividends: float, price: float) -> Optional[float]:
        """
        Calcula Dividend Yield
        
        Args:
            annual_dividends: Dividendos anuais por ação
            price: Preço da ação
        
        Returns:
            DY (em decimal) ou None
        """
        if price == 0 or price is None:
            return None
        return annual_dividends / price
    
    def calculate_all_indicators(
        self,
        price: float,
        financial_data: Dict,
        shares_outstanding: float = 1_000_000_000  # Estimativa padrão
    ) -> Dict:
        """
        Calcula todos os indicadores de uma vez
        
        Args:
            price: Preço atual da ação
            financial_data: Dicionário com dados financeiros
            shares_outstanding: Número de ações (estimativa se não fornecido)
        
        Returns:
            Dicionário com todos os indicadores
        """
        # Calcular valores por ação
        earnings_per_share = financial_data.get('net_income', 0) / shares_outstanding
        book_value_per_share = financial_data.get('shareholders_equity', 0) / shares_outstanding
        
        return {
            'price_earnings': self.calculate_price_earnings(price, earnings_per_share),
            'price_book': self.calculate_price_book(price, book_value_per_share),
            'roe': self.calculate_roe(
                financial_data.get('net_income', 0),
                financial_data.get('shareholders_equity', 1)
            ),
            'roa': self.calculate_roa(
                financial_data.get('net_income', 0),
                financial_data.get('total_assets', 1)
            ),
            'net_margin': self.calculate_net_margin(
                financial_data.get('net_income', 0),
                financial_data.get('revenue', 1)
            ),
            'debt_equity': self.calculate_debt_equity(
                financial_data.get('total_liabilities', 0),
                financial_data.get('shareholders_equity', 1)
            ),
            'dividend_yield': self.calculate_dividend_yield(
                financial_data.get('annual_dividends', 0),
                price
            )
        }


def calculate_historical_indicators(
    prices_df: pd.DataFrame,
    financials_df: pd.DataFrame
) -> pd.DataFrame:
    """
    Calcula indicadores históricos combinando preços e fundamentos
    
    Args:
        prices_df: DataFrame com colunas [date, close]
        financials_df: DataFrame com dados financeiros
    
    Returns:
        DataFrame com indicadores históricos
    """
    calculator = IndicatorCalculator()
    
    # Combinar dados
    merged = pd.merge(
        prices_df,
        financials_df,
        on='date',
        how='left'
    )
    
    # Preencher valores faltantes (forward fill)
    merged = merged.fillna(method='ffill')
    
    # Calcular indicadores para cada linha
    indicators = []
    for _, row in merged.iterrows():
        inds = calculator.calculate_all_indicators(
            price=row['close'],
            financial_data=row.to_dict()
        )
        inds['date'] = row['date']
        indicators.append(inds)
    
    return pd.DataFrame(indicators)


def test_indicators():
    """Teste do módulo de indicadores"""
    print("=== Teste Indicator Calculator ===\n")
    
    calculator = IndicatorCalculator()
    
    # Dados de teste (Empresa fictícia)
    price = 50.00
    financial_data = {
        'revenue': 10_000_000,
        'net_income': 1_500_000,
        'total_assets': 20_000_000,
        'total_liabilities': 12_000_000,
        'shareholders_equity': 8_000_000,
        'annual_dividends': 2.50
    }
    shares = 1_000_000  # 1 milhão de ações
    
    print("Dados de entrada:")
    print(f"  Preço: R$ {price:.2f}")
    print(f"  Receita: R$ {financial_data['revenue']:,.0f}")
    print(f"  Lucro Líquido: R$ {financial_data['net_income']:,.0f}")
    print(f"  Patrimônio: R$ {financial_data['shareholders_equity']:,.0f}")
    print(f"  Ações em circulação: {shares:,}\n")
    
    indicators = calculator.calculate_all_indicators(price, financial_data, shares)
    
    print("Indicadores calculados:")
    print(f"  P/L: {indicators['price_earnings']:.2f}" if indicators['price_earnings'] else "  P/L: N/A")
    print(f"  P/VP: {indicators['price_book']:.2f}" if indicators['price_book'] else "  P/VP: N/A")
    print(f"  ROE: {indicators['roe']*100:.2f}%" if indicators['roe'] else "  ROE: N/A")
    print(f"  ROA: {indicators['roa']*100:.2f}%" if indicators['roa'] else "  ROA: N/A")
    print(f"  Margem Líquida: {indicators['net_margin']*100:.2f}%" if indicators['net_margin'] else "  Margem Líquida: N/A")
    print(f"  Dívida/PL: {indicators['debt_equity']:.2f}" if indicators['debt_equity'] else "  Dívida/PL: N/A")
    print(f"  Dividend Yield: {indicators['dividend_yield']*100:.2f}%" if indicators['dividend_yield'] else "  DY: N/A")
    
    print("\n✅ Teste concluído!")


if __name__ == "__main__":
    test_indicators()
