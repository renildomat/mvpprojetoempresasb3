"""
Sistema de pontuação de oportunidades (Score 0-100)
Combina análise de divergência, qualidade fundamental e momentum
"""
import pandas as pd
import numpy as np
from typing import Dict, Optional
import logging
from src.analysis.divergence import DivergenceAnalyzer

logger = logging.getLogger(__name__)


class OpportunityScorer:
    """
    Sistema de pontuação de oportunidades de investimento
    
    Score 0-100 onde:
    - 80-100: Forte oportunidade de compra
    - 60-79: Oportunidade moderada
    - 40-59: Neutro/Hold
    - 20-39: Cuidado (possível value trap)
    - 0-19: Evitar (forte sinal de venda)
    """
    
    def __init__(self):
        self.divergence_analyzer = DivergenceAnalyzer()
        
        # Pesos dos componentes do score
        self.weights = {
            'divergence': 0.40,      # 40% - Divergência preço vs fundamentos
            'fundamentals': 0.30,    # 30% - Qualidade fundamentalista
            'momentum': 0.20,        # 20% - Momentum de preço/volume
            'valuation': 0.10        # 10% - Valuation relativo
        }
    
    def calculate_score(
        self,
        prices: pd.Series,
        earnings: pd.Series,
        indicators: Dict,
        sector_avg: Optional[Dict] = None
    ) -> Dict:
        """
        Calcula score completo de oportunidade
        
        Args:
            prices: Série de preços
            earnings: Série de lucros
            indicators: Dicionário com indicadores fundamentalistas
            sector_avg: Médias do setor (opcional)
        
        Returns:
            Dicionário com score e detalhes
        """
        # 1. Score de Divergência (0-100)
        divergence_score = self._score_divergence(prices, earnings)
        
        # 2. Score de Fundamentos (0-100)
        fundamentals_score = self._score_fundamentals(indicators)
        
        # 3. Score de Momentum (0-100)
        momentum_score = self._score_momentum(prices)
        
        # 4. Score de Valuation (0-100)
        valuation_score = self._score_valuation(indicators, sector_avg)
        
        # Score final ponderado
        final_score = (
            divergence_score * self.weights['divergence'] +
            fundamentals_score * self.weights['fundamentals'] +
            momentum_score * self.weights['momentum'] +
            valuation_score * self.weights['valuation']
        )
        
        # Determinar sinal final
        signal = self._determine_final_signal(final_score, divergence_score)
        
        # Gerar explicação
        reasoning = self._generate_final_reasoning(
            final_score,
            divergence_score,
            fundamentals_score,
            momentum_score,
            valuation_score,
            signal
        )
        
        return {
            'score': round(final_score, 2),
            'signal': signal,
            'reasoning': reasoning,
            'components': {
                'divergence': round(divergence_score, 2),
                'fundamentals': round(fundamentals_score, 2),
                'momentum': round(momentum_score, 2),
                'valuation': round(valuation_score, 2)
            }
        }
    
    def _score_divergence(self, prices: pd.Series, earnings: pd.Series) -> float:
        """
        Pontua divergência entre preço e fundamentos
        
        Returns:
            Score 0-100
        """
        analysis = self.divergence_analyzer.analyze_divergence(prices, earnings)
        
        price_trend = analysis['price_trend']
        earnings_trend = analysis['earnings_trend']
        
        # Base: 50 pontos (neutro)
        score = 50
        
        # Bônus por lucros crescendo
        if earnings_trend > 0:
            score += earnings_trend * 100  # Até +100 se earnings_trend = 1.0
        else:
            score += earnings_trend * 50   # Até -50 se earnings_trend = -1.0
        
        # Ajuste por divergência com preço
        if price_trend < 0 and earnings_trend > 0:
            # Oportunidade: preço cai, lucros sobem
            divergence_bonus = abs(price_trend - earnings_trend) * 30
            score += divergence_bonus
        elif price_trend > 0 and earnings_trend < 0:
            # Value trap: preço sobe, lucros caem
            divergence_penalty = abs(price_trend - earnings_trend) * 40
            score -= divergence_penalty
        
        return max(0, min(100, score))
    
    def _score_fundamentals(self, indicators: Dict) -> float:
        """
        Pontua qualidade fundamentalista
        
        Returns:
            Score 0-100
        """
        score = 50  # Base
        
        # ROE (quanto maior, melhor)
        roe = indicators.get('roe', 0) or 0
        if roe > 0.20:  # ROE > 20%
            score += 20
        elif roe > 0.15:  # ROE > 15%
            score += 10
        elif roe > 0.10:  # ROE > 10%
            score += 5
        elif roe < 0:  # ROE negativo
            score -= 20
        
        # Margem Líquida
        net_margin = indicators.get('net_margin', 0) or 0
        if net_margin > 0.15:  # > 15%
            score += 15
        elif net_margin > 0.10:  # > 10%
            score += 8
        elif net_margin < 0:  # Negativo
            score -= 15
        
        # Dívida/PL (quanto menor, melhor)
        debt_equity = indicators.get('debt_equity', 0) or 0
        if debt_equity < 0.5:  # Dívida baixa
            score += 10
        elif debt_equity < 1.0:  # Dívida moderada
            score += 5
        elif debt_equity > 2.0:  # Dívida alta
            score -= 15
        
        # Dividend Yield
        dy = indicators.get('dividend_yield', 0) or 0
        if dy > 0.06:  # DY > 6%
            score += 10
        elif dy > 0.04:  # DY > 4%
            score += 5
        
        return max(0, min(100, score))
    
    def _score_momentum(self, prices: pd.Series) -> float:
        """
        Pontua momentum de preço
        
        Returns:
            Score 0-100
        """
        if len(prices) < 20:
            return 50
        
        score = 50
        
        # Retorno recente (últimos 20 dias)
        recent_return = (prices.iloc[-1] / prices.iloc[-20] - 1)
        
        # Penalizar quedas recentes (possível catching a falling knife)
        if recent_return < -0.10:  # Queda > 10%
            score -= 15
        elif recent_return < -0.05:  # Queda > 5%
            score -= 8
        
        # Volume médio recente vs histórico (se disponível)
        # Por enquanto, apenas momentum de preço
        
        # Volatilidade (menor é melhor para segurança)
        volatility = prices.pct_change().std()
        if volatility > 0.05:  # Alta volatilidade
            score -= 10
        elif volatility < 0.02:  # Baixa volatilidade
            score += 5
        
        return max(0, min(100, score))
    
    def _score_valuation(self, indicators: Dict, sector_avg: Optional[Dict] = None) -> float:
        """
        Pontua valuation relativo
        
        Returns:
            Score 0-100
        """
        score = 50
        
        # P/L (quanto menor, melhor - até certo ponto)
        pe = indicators.get('price_earnings', 0) or 0
        if 0 < pe < 8:  # P/L muito baixo (pode ser barato)
            score += 20
        elif 8 <= pe < 15:  # P/L razoável
            score += 10
        elif pe >= 25:  # P/L alto
            score -= 15
        elif pe < 0:  # P/L negativo (empresa com prejuízo)
            score -= 25
        
        # P/VP (quanto menor, melhor)
        pb = indicators.get('price_book', 0) or 0
        if 0 < pb < 1.0:  # P/VP < 1 (cotando abaixo do valor patrimonial)
            score += 15
        elif 1.0 <= pb < 2.0:  # P/VP razoável
            score += 5
        elif pb >= 3.0:  # P/VP alto
            score -= 10
        
        return max(0, min(100, score))
    
    def _determine_final_signal(self, final_score: float, divergence_score: float) -> str:
        """Determina sinal final baseado no score"""
        if final_score >= 70:
            return 'BUY'
        elif final_score <= 35:
            return 'SELL'
        else:
            return 'HOLD'
    
    def _generate_final_reasoning(
        self,
        final_score: float,
        divergence: float,
        fundamentals: float,
        momentum: float,
        valuation: float,
        signal: str
    ) -> str:
        """Gera explicação textual do score"""
        
        # Identificar pontos fortes e fracos
        strengths = []
        weaknesses = []
        
        if divergence >= 60:
            strengths.append("divergência favorável preço/fundamentos")
        elif divergence <= 40:
            weaknesses.append("preço desalinhado com fundamentos")
        
        if fundamentals >= 60:
            strengths.append("fundamentos sólidos")
        elif fundamentals <= 40:
            weaknesses.append("fundamentos fracos")
        
        if valuation >= 60:
            strengths.append("valuation atrativo")
        elif valuation <= 40:
            weaknesses.append("valuation esticado")
        
        # Montar texto
        if signal == 'BUY':
            text = f"Oportunidade identificada (score {final_score:.0f}/100)"
            if strengths:
                text += f": {', '.join(strengths)}"
        elif signal == 'SELL':
            text = f"Cuidado recomendado (score {final_score:.0f}/100)"
            if weaknesses:
                text += f": {', '.join(weaknesses)}"
        else:
            text = f"Posição neutra (score {final_score:.0f}/100)"
        
        return text


def test_scorer():
    """Teste do sistema de pontuação"""
    print("=== Teste Opportunity Scorer ===\n")
    
    scorer = OpportunityScorer()
    
    # Dados de teste
    dates = pd.date_range('2024-01-01', periods=100, freq='D')
    
    # Cenário 1: Forte oportunidade
    print("Cenário 1: Forte Oportunidade")
    prices = pd.Series(50 - np.linspace(0, 10, 100), index=dates)  # Preço caindo
    earnings = pd.Series(1.0 + np.linspace(0, 0.5, 100), index=dates)  # Lucros subindo
    indicators = {
        'roe': 0.22,  # 22%
        'net_margin': 0.15,  # 15%
        'debt_equity': 0.4,  # Dívida baixa
        'dividend_yield': 0.05,  # 5%
        'price_earnings': 10,
        'price_book': 1.2
    }
    
    result = scorer.calculate_score(prices, earnings, indicators)
    print(f"  Score: {result['score']}/100")
    print(f"  Signal: {result['signal']}")
    print(f"  Reasoning: {result['reasoning']}")
    print(f"  Components: {result['components']}\n")
    
    # Cenário 2: Value Trap
    print("Cenário 2: Value Trap")
    prices = pd.Series(30 + np.linspace(0, 15, 100), index=dates)  # Preço subindo
    earnings = pd.Series(1.5 - np.linspace(0, 0.9, 100), index=dates)  # Lucros caindo
    indicators = {
        'roe': -0.05,  # ROE negativo
        'net_margin': -0.02,  # Margem negativa
        'debt_equity': 2.5,  # Dívida alta
        'dividend_yield': 0.0,
        'price_earnings': 30,  # P/L alto
        'price_book': 3.5
    }
    
    result = scorer.calculate_score(prices, earnings, indicators)
    print(f"  Score: {result['score']}/100")
    print(f"  Signal: {result['signal']}")
    print(f"  Reasoning: {result['reasoning']}")
    print(f"  Components: {result['components']}\n")
    
    print("✅ Testes concluídos!")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    test_scorer()
