"""
Análise de divergência entre preço e fundamentos
Core do sistema de detecção de oportunidades
"""
import pandas as pd
import numpy as np
from scipy import stats
from typing import Dict, List, Tuple, Optional
import logging

logger = logging.getLogger(__name__)


class DivergenceAnalyzer:
    """
    Analisador de divergências entre preço e fundamentos
    
    Detecta situações onde:
    - Preço cai mas lucros sobem (OPORTUNIDADE)
    - Preço sobe mas lucros caem (VALUE TRAP)
    - Ambos se movem na mesma direção (ALINHADO)
    """
    
    def __init__(self, lookback_period: int = 252):
        """
        Args:
            lookback_period: Dias para análise (padrão 252 = ~1 ano trading days)
        """
        self.lookback_period = lookback_period
    
    def calculate_trend(self, series: pd.Series) -> Tuple[float, float]:
        """
        Calcula tendência linear de uma série temporal
        
        Args:
            series: Série temporal (pandas Series)
        
        Returns:
            Tupla (slope, r_squared)
            - slope: inclinação (-1 a 1, normalizado)
            - r_squared: qualidade do ajuste (0 a 1)
        """
        if len(series) < 2:
            return 0.0, 0.0
        
        # Remover NaN
        series_clean = series.dropna()
        if len(series_clean) < 2:
            return 0.0, 0.0
        
        x = np.arange(len(series_clean))
        y = series_clean.values
        
        try:
            slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
            
            # Normalizar slope pelo valor médio
            mean_value = np.mean(y)
            if mean_value != 0:
                normalized_slope = (slope * len(x)) / mean_value
            else:
                normalized_slope = 0
            
            # Limitar entre -1 e 1
            normalized_slope = max(-1, min(1, normalized_slope))
            
            r_squared = r_value ** 2
            
            return normalized_slope, r_squared
            
        except Exception as e:
            logger.error(f"Erro ao calcular tendência: {e}")
            return 0.0, 0.0
    
    def analyze_divergence(
        self,
        prices: pd.Series,
        earnings: pd.Series,
        min_r_squared: float = 0.3
    ) -> Dict:
        """
        Analisa divergência entre preço e lucros
        
        Args:
            prices: Série de preços
            earnings: Série de lucros
            min_r_squared: R² mínimo para considerar tendência válida
        
        Returns:
            Dicionário com análise de divergência
        """
        # Calcular tendências
        price_trend, price_r2 = self.calculate_trend(prices)
        earnings_trend, earnings_r2 = self.calculate_trend(earnings)
        
        # Magnitude da divergência
        divergence = abs(price_trend - earnings_trend)
        
        # Determinar sinal
        signal = self._determine_signal(
            price_trend,
            earnings_trend,
            price_r2,
            earnings_r2,
            min_r_squared
        )
        
        # Explicação
        reasoning = self._generate_reasoning(
            price_trend,
            earnings_trend,
            signal,
            price_r2,
            earnings_r2
        )
        
        return {
            'price_trend': price_trend,
            'earnings_trend': earnings_trend,
            'price_r2': price_r2,
            'earnings_r2': earnings_r2,
            'divergence_magnitude': divergence,
            'signal': signal,
            'reasoning': reasoning
        }
    
    def _determine_signal(
        self,
        price_trend: float,
        earnings_trend: float,
        price_r2: float,
        earnings_r2: float,
        min_r2: float
    ) -> str:
        """
        Determina sinal de compra/venda/manutenção
        
        Returns:
            'BUY', 'SELL', ou 'HOLD'
        """
        # Se tendências não são confiáveis, HOLD
        if price_r2 < min_r2 and earnings_r2 < min_r2:
            return 'HOLD'
        
        # Thresholds
        strong_positive = 0.15
        strong_negative = -0.15
        
        # OPORTUNIDADE (BUY): Preço caindo, lucros subindo
        if price_trend < strong_negative and earnings_trend > 0:
            return 'BUY'
        
        # FORTE OPORTUNIDADE: Preço caindo muito, lucros subindo muito
        if price_trend < strong_negative and earnings_trend > strong_positive:
            return 'BUY'
        
        # VALUE TRAP (SELL): Preço subindo, lucros caindo
        if price_trend > strong_positive and earnings_trend < 0:
            return 'SELL'
        
        # FORTE VALUE TRAP
        if price_trend > strong_positive and earnings_trend < strong_negative:
            return 'SELL'
        
        # Casos moderados
        if price_trend < 0 and earnings_trend > strong_positive:
            return 'BUY'  # Lucros crescendo forte, preço lateralizando/caindo
        
        if price_trend > 0 and earnings_trend < strong_negative:
            return 'SELL'  # Lucros caindo forte, preço ainda subindo
        
        return 'HOLD'
    
    def _generate_reasoning(
        self,
        price_trend: float,
        earnings_trend: float,
        signal: str,
        price_r2: float,
        earnings_r2: float
    ) -> str:
        """Gera explicação textual da análise"""
        
        # Descrições de tendência
        def describe_trend(trend: float, r2: float) -> str:
            if r2 < 0.3:
                return "lateralizando"
            elif trend > 0.15:
                return "em forte alta"
            elif trend > 0:
                return "em leve alta"
            elif trend < -0.15:
                return "em forte queda"
            elif trend < 0:
                return "em leve queda"
            else:
                return "estável"
        
        price_desc = describe_trend(price_trend, price_r2)
        earnings_desc = describe_trend(earnings_trend, earnings_r2)
        
        if signal == 'BUY':
            if price_trend < 0 and earnings_trend > 0:
                return f"Oportunidade: Preço {price_desc} enquanto lucros estão {earnings_desc}"
            else:
                return f"Potencial de alta: Fundamentos {earnings_desc}"
        
        elif signal == 'SELL':
            if price_trend > 0 and earnings_trend < 0:
                return f"Alerta (value trap): Preço {price_desc} mas lucros {earnings_desc}"
            else:
                return f"Cuidado: Fundamentos deteriorando ({earnings_desc})"
        
        else:  # HOLD
            return f"Preço e fundamentos alinhados (preço {price_desc}, lucros {earnings_desc})"


def test_divergence_analyzer():
    """Teste do analisador de divergência"""
    print("=== Teste Divergence Analyzer ===\n")
    
    analyzer = DivergenceAnalyzer()
    
    # Cenário 1: OPORTUNIDADE (preço cai, lucro sobe)
    print("Cenário 1: Oportunidade (preço caindo, lucros subindo)")
    dates = pd.date_range('2024-01-01', periods=100, freq='D')
    prices = pd.Series(50 - np.linspace(0, 10, 100), index=dates)  # Caindo de 50 para 40
    earnings = pd.Series(1.0 + np.linspace(0, 0.5, 100), index=dates)  # Subindo de 1.0 para 1.5
    
    result = analyzer.analyze_divergence(prices, earnings)
    print(f"  Signal: {result['signal']}")
    print(f"  Reasoning: {result['reasoning']}")
    print(f"  Price Trend: {result['price_trend']:.3f}")
    print(f"  Earnings Trend: {result['earnings_trend']:.3f}")
    print(f"  Divergence: {result['divergence_magnitude']:.3f}\n")
    
    # Cenário 2: VALUE TRAP (preço sobe, lucro cai)
    print("Cenário 2: Value Trap (preço subindo, lucros caindo)")
    prices = pd.Series(30 + np.linspace(0, 15, 100), index=dates)  # Subindo de 30 para 45
    earnings = pd.Series(1.5 - np.linspace(0, 0.8, 100), index=dates)  # Caindo de 1.5 para 0.7
    
    result = analyzer.analyze_divergence(prices, earnings)
    print(f"  Signal: {result['signal']}")
    print(f"  Reasoning: {result['reasoning']}")
    print(f"  Price Trend: {result['price_trend']:.3f}")
    print(f"  Earnings Trend: {result['earnings_trend']:.3f}")
    print(f"  Divergence: {result['divergence_magnitude']:.3f}\n")
    
    # Cenário 3: ALINHADO (ambos sobem)
    print("Cenário 3: Alinhado (ambos subindo)")
    prices = pd.Series(40 + np.linspace(0, 10, 100), index=dates)  # Subindo de 40 para 50
    earnings = pd.Series(1.0 + np.linspace(0, 0.4, 100), index=dates)  # Subindo de 1.0 para 1.4
    
    result = analyzer.analyze_divergence(prices, earnings)
    print(f"  Signal: {result['signal']}")
    print(f"  Reasoning: {result['reasoning']}")
    print(f"  Price Trend: {result['price_trend']:.3f}")
    print(f"  Earnings Trend: {result['earnings_trend']:.3f}")
    print(f"  Divergence: {result['divergence_magnitude']:.3f}\n")
    
    print("✅ Testes concluídos!")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    test_divergence_analyzer()
