"""
Modelos de banco de dados usando SQLAlchemy
"""
from sqlalchemy import Column, Integer, String, Float, Date, DateTime, Boolean, Text, ForeignKey
from sqlalchemy.orm import declarative_base, relationship
from datetime import datetime

Base = declarative_base()


class Stock(Base):
    """Modelo de Ação"""
    __tablename__ = 'stocks'
    
    id = Column(Integer, primary_key=True)
    ticker = Column(String(10), unique=True, nullable=False, index=True)
    company_name = Column(String(255), nullable=False)
    cnpj = Column(String(18))
    sector = Column(String(100))
    subsector = Column(String(100))
    market_cap = Column(Float)
    average_volume = Column(Float)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    # Relationships
    prices = relationship("StockPrice", back_populates="stock", cascade="all, delete-orphan")
    financials = relationship("FinancialStatement", back_populates="stock", cascade="all, delete-orphan")
    indicators = relationship("FundamentalIndicator", back_populates="stock", cascade="all, delete-orphan")
    scores = relationship("OpportunityScore", back_populates="stock", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Stock(ticker='{self.ticker}', name='{self.company_name}')>"


class StockPrice(Base):
    """Modelo de Preços/Cotações"""
    __tablename__ = 'stock_prices'
    
    id = Column(Integer, primary_key=True)
    stock_id = Column(Integer, ForeignKey('stocks.id', ondelete='CASCADE'), nullable=False)
    date = Column(Date, nullable=False, index=True)
    open = Column(Float)
    high = Column(Float)
    low = Column(Float)
    close = Column(Float)
    volume = Column(Float)
    created_at = Column(DateTime, default=datetime.now)
    
    # Relationship
    stock = relationship("Stock", back_populates="prices")
    
    __table_args__ = (
        {'sqlite_autoincrement': True},
    )
    
    def __repr__(self):
        return f"<StockPrice(ticker='{self.stock.ticker if self.stock else 'N/A'}', date='{self.date}', close={self.close})>"


class FinancialStatement(Base):
    """Modelo de Demonstrativos Financeiros"""
    __tablename__ = 'financial_statements'
    
    id = Column(Integer, primary_key=True)
    stock_id = Column(Integer, ForeignKey('stocks.id', ondelete='CASCADE'), nullable=False)
    period = Column(Date, nullable=False, index=True)
    period_type = Column(String(10))  # 'Q' (trimestral) ou 'Y' (anual)
    revenue = Column(Float)
    gross_profit = Column(Float)
    operating_income = Column(Float)
    net_income = Column(Float)
    ebitda = Column(Float)
    total_assets = Column(Float)
    total_liabilities = Column(Float)
    shareholders_equity = Column(Float)
    created_at = Column(DateTime, default=datetime.now)
    
    # Relationship
    stock = relationship("Stock", back_populates="financials")
    
    def __repr__(self):
        return f"<FinancialStatement(ticker='{self.stock.ticker if self.stock else 'N/A'}', period='{self.period}')>"


class FundamentalIndicator(Base):
    """Modelo de Indicadores Fundamentalistas"""
    __tablename__ = 'fundamental_indicators'
    
    id = Column(Integer, primary_key=True)
    stock_id = Column(Integer, ForeignKey('stocks.id', ondelete='CASCADE'), nullable=False)
    date = Column(Date, nullable=False, index=True)
    price_earnings = Column(Float)  # P/L
    price_book = Column(Float)  # P/VP
    roe = Column(Float)  # ROE
    roa = Column(Float)  # ROA
    net_margin = Column(Float)
    debt_equity = Column(Float)
    dividend_yield = Column(Float)
    created_at = Column(DateTime, default=datetime.now)
    
    # Relationship
    stock = relationship("Stock", back_populates="indicators")
    
    def __repr__(self):
        return f"<FundamentalIndicator(ticker='{self.stock.ticker if self.stock else 'N/A'}', date='{self.date}')>"


class OpportunityScore(Base):
    """Modelo de Scores de Oportunidade"""
    __tablename__ = 'opportunity_scores'
    
    id = Column(Integer, primary_key=True)
    stock_id = Column(Integer, ForeignKey('stocks.id', ondelete='CASCADE'), nullable=False)
    date = Column(Date, nullable=False, index=True)
    score = Column(Integer)  # 0-100
    signal = Column(String(10))  # 'BUY', 'SELL', 'HOLD'
    reasoning = Column(Text)
    price_trend = Column(Float)
    earnings_trend = Column(Float)
    divergence_magnitude = Column(Float)
    created_at = Column(DateTime, default=datetime.now)
    
    # Relationship
    stock = relationship("Stock", back_populates="scores")
    
    def __repr__(self):
        return f"<OpportunityScore(ticker='{self.stock.ticker if self.stock else 'N/A'}', score={self.score}, signal='{self.signal}')>"


class JobLog(Base):
    """Modelo de Log de Jobs Automatizados"""
    __tablename__ = 'job_logs'
    
    id = Column(Integer, primary_key=True)
    job_name = Column(String(100), nullable=False)
    status = Column(String(20))  # 'SUCCESS', 'FAILED', 'RUNNING'
    started_at = Column(DateTime, nullable=False)
    finished_at = Column(DateTime)
    records_processed = Column(Integer)
    error_message = Column(Text)
    
    def __repr__(self):
        return f"<JobLog(job='{self.job_name}', status='{self.status}')>"
