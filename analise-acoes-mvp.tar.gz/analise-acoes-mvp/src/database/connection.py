"""
Gerenciamento de conexão com banco de dados
"""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool
from pathlib import Path
from typing import Generator

# Caminho do banco de dados
BASE_DIR = Path(__file__).resolve().parent.parent.parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{DATA_DIR}/stocks.db")

# Configuração do engine
if DATABASE_URL.startswith("sqlite"):
    engine = create_engine(
        DATABASE_URL,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
        echo=False  # Mudar para True para debug SQL
    )
else:
    # PostgreSQL ou outro
    engine = create_engine(DATABASE_URL, pool_pre_ping=True, echo=False)

# Session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db() -> Generator[Session, None, None]:
    """
    Dependency para obter sessão do banco de dados
    
    Uso:
        with get_db() as db:
            stocks = db.query(Stock).all()
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_session() -> Session:
    """
    Retorna uma nova sessão do banco de dados
    Deve ser fechada manualmente com session.close()
    """
    return SessionLocal()


def init_database():
    """
    Inicializa o banco de dados criando todas as tabelas
    """
    from src.database.models import Base
    Base.metadata.create_all(bind=engine)
    print(f"✅ Banco de dados inicializado em: {DATABASE_URL}")


def drop_all_tables():
    """
    CUIDADO: Apaga todas as tabelas do banco
    Usar apenas em desenvolvimento
    """
    from src.database.models import Base
    Base.metadata.drop_all(bind=engine)
    print("⚠️  Todas as tabelas foram apagadas!")


def reset_database():
    """
    Reseta o banco de dados (drop + create)
    """
    drop_all_tables()
    init_database()


if __name__ == "__main__":
    # Teste de conexão
    init_database()
    
    # Testar inserção
    from src.database.models import Stock
    session = get_session()
    
    # Verificar se já existe
    existing = session.query(Stock).filter_by(ticker="PETR4").first()
    if not existing:
        test_stock = Stock(
            ticker="PETR4",
            company_name="Petróleo Brasileiro S.A. - Petrobras",
            sector="Petróleo, Gás e Biocombustíveis"
        )
        session.add(test_stock)
        session.commit()
        print(f"✅ Ação de teste criada: {test_stock}")
    else:
        print(f"ℹ️  Ação de teste já existe: {existing}")
    
    session.close()
