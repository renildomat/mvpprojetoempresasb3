"""
Sistema de logging configurado
"""
import logging
import sys
from pathlib import Path
from datetime import datetime


def setup_logging(level=logging.INFO, log_file=None):
    """
    Configura sistema de logging
    
    Args:
        level: Nível de logging (INFO, DEBUG, WARNING, ERROR)
        log_file: Path para arquivo de log (opcional)
    """
    # Formato do log
    log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    date_format = '%Y-%m-%d %H:%M:%S'
    
    # Configuração base
    logging.basicConfig(
        level=level,
        format=log_format,
        datefmt=date_format,
        handlers=[]
    )
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_formatter = logging.Formatter(log_format, date_format)
    console_handler.setFormatter(console_formatter)
    
    # Root logger
    root_logger = logging.getLogger()
    root_logger.addHandler(console_handler)
    
    # File handler (opcional)
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)  # Arquivo sempre em DEBUG
        file_formatter = logging.Formatter(log_format, date_format)
        file_handler.setFormatter(file_formatter)
        root_logger.addHandler(file_handler)
    
    return root_logger


def get_logger(name: str) -> logging.Logger:
    """
    Retorna logger configurado
    
    Args:
        name: Nome do logger (geralmente __name__)
    
    Returns:
        Logger configurado
    """
    return logging.getLogger(name)


# Configurar logging padrão ao importar
setup_logging()
