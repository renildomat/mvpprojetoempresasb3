"""
Funções auxiliares gerais
"""
from datetime import datetime, timedelta
from typing import Optional
import pandas as pd


def format_currency(value: Optional[float], prefix: str = "R$") -> str:
    """
    Formata valor como moeda
    
    Args:
        value: Valor numérico
        prefix: Prefixo da moeda
    
    Returns:
        String formatada (ex: "R$ 1.234,56")
    """
    if value is None or pd.isna(value):
        return "N/A"
    
    if abs(value) >= 1_000_000_000:  # Bilhões
        return f"{prefix} {value/1_000_000_000:.2f}B"
    elif abs(value) >= 1_000_000:  # Milhões
        return f"{prefix} {value/1_000_000:.2f}M"
    elif abs(value) >= 1_000:  # Milhares
        return f"{prefix} {value/1_000:.2f}K"
    else:
        return f"{prefix} {value:.2f}"


def format_percentage(value: Optional[float], decimals: int = 2) -> str:
    """
    Formata valor como percentual
    
    Args:
        value: Valor decimal (ex: 0.15 = 15%)
        decimals: Casas decimais
    
    Returns:
        String formatada (ex: "15.00%")
    """
    if value is None or pd.isna(value):
        return "N/A"
    
    return f"{value * 100:.{decimals}f}%"


def format_number(value: Optional[float], decimals: int = 2) -> str:
    """
    Formata número com separadores
    
    Args:
        value: Valor numérico
        decimals: Casas decimais
    
    Returns:
        String formatada
    """
    if value is None or pd.isna(value):
        return "N/A"
    
    return f"{value:,.{decimals}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def get_color_for_value(value: float, reverse: bool = False) -> str:
    """
    Retorna cor baseada no valor (verde positivo, vermelho negativo)
    
    Args:
        value: Valor a colorir
        reverse: Se True, inverte as cores
    
    Returns:
        Código de cor hexadecimal
    """
    if value is None or pd.isna(value):
        return "#6B7280"  # Cinza
    
    if reverse:
        return "#EF4444" if value > 0 else "#10B981"  # Vermelho se positivo
    else:
        return "#10B981" if value > 0 else "#EF4444"  # Verde se positivo


def get_color_for_signal(signal: str) -> str:
    """
    Retorna cor baseada no sinal
    
    Args:
        signal: 'BUY', 'SELL', ou 'HOLD'
    
    Returns:
        Código de cor hexadecimal
    """
    colors = {
        'BUY': "#10B981",    # Verde
        'SELL': "#EF4444",   # Vermelho
        'HOLD': "#F59E0B"    # Laranja
    }
    return colors.get(signal, "#6B7280")


def calculate_date_range(period: str) -> tuple:
    """
    Calcula range de datas baseado no período
    
    Args:
        period: '1M', '3M', '6M', '1Y', '5Y', 'ALL'
    
    Returns:
        Tupla (start_date, end_date)
    """
    end_date = datetime.now().date()
    
    period_map = {
        '1M': timedelta(days=30),
        '3M': timedelta(days=90),
        '6M': timedelta(days=180),
        '1Y': timedelta(days=365),
        '5Y': timedelta(days=365*5)
    }
    
    if period == 'ALL':
        start_date = datetime(2019, 1, 1).date()  # Desde 2019
    else:
        delta = period_map.get(period, timedelta(days=365))
        start_date = end_date - delta
    
    return start_date, end_date


def safe_divide(numerator: float, denominator: float, default: float = 0) -> float:
    """
    Divisão segura (evita divisão por zero)
    
    Args:
        numerator: Numerador
        denominator: Denominador
        default: Valor padrão se divisão inválida
    
    Returns:
        Resultado da divisão ou default
    """
    try:
        if denominator == 0 or pd.isna(denominator):
            return default
        return numerator / denominator
    except:
        return default


def truncate_text(text: str, max_length: int = 50) -> str:
    """
    Trunca texto com reticências
    
    Args:
        text: Texto original
        max_length: Comprimento máximo
    
    Returns:
        Texto truncado
    """
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + "..."


def get_score_badge(score: float) -> dict:
    """
    Retorna configuração de badge baseado no score
    
    Args:
        score: Score de 0-100
    
    Returns:
        Dict com 'color', 'label', 'emoji'
    """
    if score >= 80:
        return {
            'color': '#10B981',
            'label': 'Forte Oportunidade',
            'emoji': '🚀'
        }
    elif score >= 60:
        return {
            'color': '#3B82F6',
            'label': 'Oportunidade',
            'emoji': '📈'
        }
    elif score >= 40:
        return {
            'color': '#F59E0B',
            'label': 'Neutro',
            'emoji': '➡️'
        }
    elif score >= 20:
        return {
            'color': '#EF4444',
            'label': 'Cuidado',
            'emoji': '⚠️'
        }
    else:
        return {
            'color': '#DC2626',
            'label': 'Evitar',
            'emoji': '🛑'
        }
