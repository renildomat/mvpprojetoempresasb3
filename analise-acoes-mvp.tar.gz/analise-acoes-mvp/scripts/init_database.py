"""
Script para inicializar o banco de dados
Cria todas as tabelas necessárias
"""
import sys
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.database import init_database
from src.utils.logger import setup_logging
import logging

if __name__ == "__main__":
    # Setup logging
    setup_logging(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    logger.info("=" * 50)
    logger.info("Inicializando Banco de Dados")
    logger.info("=" * 50)
    
    try:
        init_database()
        logger.info("✅ Banco de dados inicializado com sucesso!")
        logger.info("\nPróximo passo: python scripts/seed_data.py")
        
    except Exception as e:
        logger.error(f"❌ Erro ao inicializar banco: {e}")
        sys.exit(1)
