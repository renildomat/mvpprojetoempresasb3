"""
Script para popular banco de dados com dados iniciais
Executa todos os jobs necessários para ter dados completos
"""
import sys
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.jobs.tasks import JobRunner
from src.utils.logger import setup_logging
import logging

if __name__ == "__main__":
    # Setup logging
    setup_logging(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    logger.info("=" * 50)
    logger.info("Populando Banco de Dados com Dados Iniciais")
    logger.info("=" * 50)
    logger.info("\n⚠️  Este processo pode levar alguns minutos...\n")
    
    runner = JobRunner()
    
    try:
        # Passo 1: Cadastrar ações
        logger.info("📊 PASSO 1/4: Cadastrando ações da B3...")
        runner.update_stocks_info()
        
        # Passo 2: Baixar histórico de preços (5 anos)
        logger.info("\n📈 PASSO 2/4: Baixando histórico de preços...")
        logger.info("   (Este passo pode demorar ~5 minutos)")
        runner.update_stock_prices()
        
        # Passo 3: Buscar dados fundamentalistas
        logger.info("\n💼 PASSO 3/4: Coletando dados fundamentalistas...")
        runner.update_cvm_data()
        
        # Passo 4: Calcular scores
        logger.info("\n🎯 PASSO 4/4: Calculando scores de oportunidade...")
        runner.calculate_opportunity_scores()
        
        logger.info("\n" + "=" * 50)
        logger.info("✅ BANCO DE DADOS POPULADO COM SUCESSO!")
        logger.info("=" * 50)
        logger.info("\n🚀 Agora você pode executar: streamlit run app.py")
        
    except Exception as e:
        logger.error(f"\n❌ Erro durante população do banco: {e}")
        logger.error("Tente executar novamente ou execute os jobs individualmente")
        sys.exit(1)
