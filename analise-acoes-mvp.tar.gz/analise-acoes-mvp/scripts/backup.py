"""
Script para fazer backup do banco de dados
"""
import sys
from pathlib import Path
import shutil
from datetime import datetime

# Adicionar src ao path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.utils.logger import setup_logging
import logging

if __name__ == "__main__":
    # Setup logging
    setup_logging(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    # Caminhos
    BASE_DIR = Path(__file__).parent.parent
    DATA_DIR = BASE_DIR / "data"
    BACKUP_DIR = DATA_DIR / "backups"
    BACKUP_DIR.mkdir(exist_ok=True)
    
    DB_FILE = DATA_DIR / "stocks.db"
    
    if not DB_FILE.exists():
        logger.error(f"❌ Banco de dados não encontrado: {DB_FILE}")
        sys.exit(1)
    
    # Nome do backup com timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = BACKUP_DIR / f"stocks_backup_{timestamp}.db"
    
    try:
        logger.info(f"📦 Criando backup do banco de dados...")
        logger.info(f"   Origem: {DB_FILE}")
        logger.info(f"   Destino: {backup_file}")
        
        # Copiar arquivo
        shutil.copy2(DB_FILE, backup_file)
        
        # Verificar tamanho
        size_mb = backup_file.stat().st_size / (1024 * 1024)
        logger.info(f"✅ Backup criado com sucesso! ({size_mb:.2f} MB)")
        
        # Listar backups existentes
        backups = sorted(BACKUP_DIR.glob("stocks_backup_*.db"))
        logger.info(f"\n📋 Total de backups: {len(backups)}")
        
        # Manter apenas últimos 7 backups
        if len(backups) > 7:
            logger.info("🗑️  Removendo backups antigos...")
            for old_backup in backups[:-7]:
                old_backup.unlink()
                logger.info(f"   Removido: {old_backup.name}")
        
        logger.info("\n✅ Processo de backup concluído!")
        
    except Exception as e:
        logger.error(f"❌ Erro ao criar backup: {e}")
        sys.exit(1)
