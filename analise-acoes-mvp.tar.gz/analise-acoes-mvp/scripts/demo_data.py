"""
Script para popular banco com dados de demonstração
Usado quando não há acesso à internet ou para testes
"""
import sys
from pathlib import Path
import random
from datetime import datetime, timedelta

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.database import get_session, Stock, StockPrice, FinancialStatement, FundamentalIndicator, OpportunityScore
from src.utils.logger import setup_logging
import logging

setup_logging(level=logging.INFO)
logger = logging.getLogger(__name__)


def create_demo_data():
    """Cria dados de demonstração realistas"""
    session = get_session()
    
    try:
        logger.info("🎭 Criando dados de DEMONSTRAÇÃO...")
        
        # Lista de ações demo
        demo_stocks = [
            {"ticker": "PETR4", "name": "Petróleo Brasileiro S.A. - Petrobras", "sector": "Petróleo, Gás e Biocombustíveis"},
            {"ticker": "VALE3", "name": "Vale S.A.", "sector": "Mineração"},
            {"ticker": "ITUB4", "name": "Itaú Unibanco Holding S.A.", "sector": "Bancos"},
            {"ticker": "BBDC4", "name": "Banco Bradesco S.A.", "sector": "Bancos"},
            {"ticker": "WEGE3", "name": "WEG S.A.", "sector": "Máquinas e Equipamentos"},
            {"ticker": "RENT3", "name": "Localiza Rent a Car S.A.", "sector": "Aluguel de Carros"},
            {"ticker": "RADL3", "name": "Raia Drogasil S.A.", "sector": "Comércio"},
            {"ticker": "MGLU3", "name": "Magazine Luiza S.A.", "sector": "Comércio"},
            {"ticker": "ABEV3", "name": "Ambev S.A.", "sector": "Bebidas"},
            {"ticker": "SUZB3", "name": "Suzano S.A.", "sector": "Papel e Celulose"}
        ]
        
        # 1. Criar ações
        logger.info("\n📊 Criando ações...")
        stocks_created = []
        for stock_data in demo_stocks:
            stock = Stock(
                ticker=stock_data["ticker"],
                company_name=stock_data["name"],
                sector=stock_data["sector"],
                subsector="Diversos",
                market_cap=random.uniform(10_000_000_000, 500_000_000_000),
                average_volume=random.uniform(1_000_000, 100_000_000)
            )
            session.add(stock)
            stocks_created.append(stock)
            logger.info(f"  ✅ {stock_data['ticker']} - {stock_data['name']}")
        
        session.commit()
        
        # 2. Criar preços históricos (últimos 2 anos)
        logger.info("\n💹 Criando histórico de preços (2 anos)...")
        end_date = datetime.now().date()
        start_date = end_date - timedelta(days=730)
        
        for stock in stocks_created:
            base_price = random.uniform(10, 100)
            trend = random.choice([-0.0005, -0.0002, 0, 0.0002, 0.0005])  # Tendência diária
            
            current_date = start_date
            current_price = base_price
            
            prices_count = 0
            while current_date <= end_date:
                # Simular variação diária
                daily_change = random.uniform(-0.03, 0.03)  # -3% a +3%
                current_price = current_price * (1 + daily_change + trend)
                current_price = max(current_price, base_price * 0.5)  # Não cair menos que 50%
                current_price = min(current_price, base_price * 3)  # Não subir mais que 300%
                
                price = StockPrice(
                    stock_id=stock.id,
                    date=current_date,
                    open=current_price * random.uniform(0.98, 1.02),
                    high=current_price * random.uniform(1.0, 1.05),
                    low=current_price * random.uniform(0.95, 1.0),
                    close=current_price,
                    volume=int(random.uniform(1_000_000, 50_000_000))
                )
                session.add(price)
                prices_count += 1
                
                current_date += timedelta(days=1)
            
            logger.info(f"  ✅ {stock.ticker}: {prices_count} preços")
            session.commit()
        
        # 3. Criar demonstrativos financeiros (20 trimestres)
        logger.info("\n💼 Criando demonstrativos financeiros...")
        for stock in stocks_created:
            base_revenue = random.uniform(1_000_000, 50_000_000)
            
            for i in range(20):
                quarter = 20 - i
                year = 2021 + (quarter // 4)
                q = (quarter % 4) + 1
                period_date = datetime(year, q*3, 1).date()
                
                # Crescimento trimestral
                growth = random.uniform(0.95, 1.15)
                revenue = base_revenue * growth * (1 + i * 0.02)
                
                # Margens
                gross_margin = random.uniform(0.25, 0.45)
                operating_margin = random.uniform(0.10, 0.30)
                net_margin = random.uniform(0.05, 0.25)
                
                financial = FinancialStatement(
                    stock_id=stock.id,
                    period=period_date,
                    period_type='Q',
                    revenue=revenue,
                    gross_profit=revenue * gross_margin,
                    operating_income=revenue * operating_margin,
                    net_income=revenue * net_margin,
                    ebitda=revenue * (operating_margin + 0.05),
                    total_assets=revenue * 3.5,
                    total_liabilities=revenue * 2.0,
                    shareholders_equity=revenue * 1.5
                )
                session.add(financial)
            
            logger.info(f"  ✅ {stock.ticker}: 20 demonstrativos")
            session.commit()
        
        # 4. Criar indicadores fundamentalistas
        logger.info("\n📊 Criando indicadores fundamentalistas...")
        today = datetime.now().date()
        
        for stock in stocks_created:
            # Pegar último preço
            latest_price_obj = session.query(StockPrice).filter_by(
                stock_id=stock.id
            ).order_by(StockPrice.date.desc()).first()
            
            latest_price = latest_price_obj.close if latest_price_obj else 50
            
            # Gerar indicadores realistas
            indicator = FundamentalIndicator(
                stock_id=stock.id,
                date=today,
                price_earnings=random.uniform(5, 35),
                price_book=random.uniform(0.5, 5.0),
                roe=random.uniform(0.05, 0.30),
                roa=random.uniform(0.02, 0.15),
                net_margin=random.uniform(0.05, 0.25),
                debt_equity=random.uniform(0.2, 2.5),
                dividend_yield=random.uniform(0, 0.08)
            )
            session.add(indicator)
            logger.info(f"  ✅ {stock.ticker}")
        
        session.commit()
        
        # 5. Criar scores de oportunidade
        logger.info("\n🎯 Criando scores de oportunidade...")
        
        for stock in stocks_created:
            # Score aleatório mas com distribuição realista
            score_type = random.choice(['buy', 'hold', 'sell'])
            
            if score_type == 'buy':
                score = random.randint(70, 95)
                signal = 'BUY'
                reasoning = f"Oportunidade: Preço {random.choice(['em queda', 'lateralizando'])} enquanto lucros estão {random.choice(['em alta', 'crescendo'])}"
            elif score_type == 'sell':
                score = random.randint(10, 35)
                signal = 'SELL'
                reasoning = f"Alerta (value trap): Preço {random.choice(['em alta', 'subindo'])} mas lucros {random.choice(['em queda', 'deteriorando'])}"
            else:
                score = random.randint(40, 69)
                signal = 'HOLD'
                reasoning = "Preço e fundamentos alinhados"
            
            opp_score = OpportunityScore(
                stock_id=stock.id,
                date=today,
                score=score,
                signal=signal,
                reasoning=reasoning,
                price_trend=random.uniform(-0.5, 0.5),
                earnings_trend=random.uniform(-0.5, 0.5),
                divergence_magnitude=random.uniform(0, 1.0)
            )
            session.add(opp_score)
            logger.info(f"  ✅ {stock.ticker}: Score {score} ({signal})")
        
        session.commit()
        
        logger.info("\n" + "="*50)
        logger.info("✅ DADOS DE DEMONSTRAÇÃO CRIADOS COM SUCESSO!")
        logger.info("="*50)
        logger.info(f"\n📊 Resumo:")
        logger.info(f"  • {len(stocks_created)} ações cadastradas")
        logger.info(f"  • ~730 preços por ação (2 anos)")
        logger.info(f"  • 20 demonstrativos trimestrais por ação")
        logger.info(f"  • Indicadores e scores atualizados")
        logger.info(f"\n🚀 Execute: streamlit run app.py")
        
    except Exception as e:
        session.rollback()
        logger.error(f"❌ Erro: {e}")
        raise
    finally:
        session.close()


if __name__ == "__main__":
    create_demo_data()
