"""
Página 4: Configurações
Painel administrativo para executar jobs e ver status do sistema
"""
import streamlit as st
import pandas as pd
from datetime import datetime

st.set_page_config(page_title="Configurações - B3", page_icon="⚙️", layout="wide")

from src.database import get_session, Stock, StockPrice, OpportunityScore, JobLog
from src.jobs import get_scheduler
from components.cards import stat_box, info_card, alert_card
from src.utils.helpers import format_currency


def get_system_stats():
    """Retorna estatísticas do sistema"""
    session = get_session()
    
    try:
        # Contagens
        total_stocks = session.query(Stock).count()
        total_prices = session.query(StockPrice).count()
        total_scores = session.query(OpportunityScore).count()
        
        # Última atualização
        latest_price = session.query(StockPrice).order_by(
            StockPrice.created_at.desc()
        ).first()
        
        latest_score = session.query(OpportunityScore).order_by(
            OpportunityScore.created_at.desc()
        ).first()
        
        # Jobs recentes
        recent_jobs = session.query(JobLog).order_by(
            JobLog.finished_at.desc()
        ).limit(10).all()
        
        return {
            'total_stocks': total_stocks,
            'total_prices': total_prices,
            'total_scores': total_scores,
            'latest_price_update': latest_price.created_at if latest_price else None,
            'latest_score_update': latest_score.created_at if latest_score else None,
            'recent_jobs': recent_jobs
        }
        
    finally:
        session.close()


def main():
    st.title("⚙️ Configurações e Administração")
    st.markdown("Painel de controle do sistema")
    
    st.markdown("---")
    
    # Carregar stats
    stats = get_system_stats()
    
    # Estatísticas do Sistema
    st.subheader("📊 Estatísticas do Sistema")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        stat_box(
            "Ações Cadastradas",
            str(stats['total_stocks']),
            "📊",
            "#1E40AF"
        )
    
    with col2:
        stat_box(
            "Registros de Preços",
            f"{stats['total_prices']:,}",
            "💹",
            "#10B981"
        )
    
    with col3:
        stat_box(
            "Scores Calculados",
            str(stats['total_scores']),
            "🎯",
            "#F59E0B"
        )
    
    with col4:
        jobs_success = sum(1 for j in stats['recent_jobs'] if j.status == 'SUCCESS')
        jobs_total = len(stats['recent_jobs'])
        stat_box(
            "Taxa de Sucesso Jobs",
            f"{jobs_success}/{jobs_total}",
            "✅",
            "#10B981" if jobs_success == jobs_total else "#EF4444"
        )
    
    st.markdown("---")
    
    # Últimas Atualizações
    st.subheader("🕐 Últimas Atualizações")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if stats['latest_price_update']:
            update_time = stats['latest_price_update'].strftime('%d/%m/%Y %H:%M:%S')
            info_card(
                "💹 Preços",
                f"Última atualização: {update_time}",
                "💹"
            )
        else:
            alert_card("Preços nunca foram atualizados", "warning")
    
    with col2:
        if stats['latest_score_update']:
            update_time = stats['latest_score_update'].strftime('%d/%m/%Y %H:%M:%S')
            info_card(
                "🎯 Scores",
                f"Última atualização: {update_time}",
                "🎯"
            )
        else:
            alert_card("Scores nunca foram calculados", "warning")
    
    st.markdown("---")
    
    # Jobs Manuais
    st.subheader("🔧 Executar Jobs Manualmente")
    
    st.warning("⚠️ **Atenção:** Executar jobs manualmente pode demorar vários minutos. Use apenas quando necessário.")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if st.button("📊 Atualizar Informações de Ações", use_container_width=True):
            with st.spinner("Atualizando informações..."):
                try:
                    from src.jobs.tasks import JobRunner
                    runner = JobRunner()
                    runner.update_stocks_info()
                    st.success("✅ Informações atualizadas com sucesso!")
                    st.rerun()
                except Exception as e:
                    st.error(f"❌ Erro: {e}")
    
    with col2:
        if st.button("💹 Atualizar Cotações", use_container_width=True):
            with st.spinner("Baixando cotações... (pode levar 5-10 min)"):
                try:
                    from src.jobs.tasks import JobRunner
                    runner = JobRunner()
                    runner.update_stock_prices()
                    st.success("✅ Cotações atualizadas!")
                    st.rerun()
                except Exception as e:
                    st.error(f"❌ Erro: {e}")
    
    with col3:
        if st.button("💼 Atualizar Dados CVM", use_container_width=True):
            with st.spinner("Coletando dados CVM..."):
                try:
                    from src.jobs.tasks import JobRunner
                    runner = JobRunner()
                    runner.update_cvm_data()
                    st.success("✅ Dados CVM atualizados!")
                    st.rerun()
                except Exception as e:
                    st.error(f"❌ Erro: {e}")
    
    with col4:
        if st.button("🎯 Calcular Scores", use_container_width=True):
            with st.spinner("Calculando scores..."):
                try:
                    from src.jobs.tasks import JobRunner
                    runner = JobRunner()
                    runner.calculate_opportunity_scores()
                    st.success("✅ Scores calculados!")
                    st.rerun()
                except Exception as e:
                    st.error(f"❌ Erro: {e}")
    
    st.markdown("---")
    
    # Histórico de Jobs
    st.subheader("📋 Histórico de Jobs")
    
    if stats['recent_jobs']:
        jobs_data = []
        for job in stats['recent_jobs']:
            status_emoji = "✅" if job.status == "SUCCESS" else "❌"
            
            duration = ""
            if job.finished_at and job.started_at:
                delta = job.finished_at - job.started_at
                duration = f"{delta.total_seconds():.1f}s"
            
            jobs_data.append({
                'Status': f"{status_emoji} {job.status}",
                'Job': job.job_name,
                'Início': job.started_at.strftime('%d/%m/%Y %H:%M:%S'),
                'Fim': job.finished_at.strftime('%d/%m/%Y %H:%M:%S') if job.finished_at else "N/A",
                'Duração': duration,
                'Registros': job.records_processed or 0,
                'Erro': job.error_message[:50] + '...' if job.error_message and len(job.error_message) > 50 else job.error_message or ""
            })
        
        jobs_df = pd.DataFrame(jobs_data)
        
        st.dataframe(
            jobs_df,
            use_container_width=True,
            hide_index=True,
            column_config={
                'Registros': st.column_config.NumberColumn('Registros', format='%d')
            }
        )
    else:
        st.info("Nenhum job executado ainda")
    
    st.markdown("---")
    
    # Scheduler Status
    st.subheader("⏰ Status do Scheduler (Jobs Automáticos)")
    
    try:
        scheduler = get_scheduler()
        
        if scheduler.is_running:
            st.success("✅ Scheduler está rodando")
            
            jobs_status = scheduler.get_jobs_status()
            
            if jobs_status:
                st.markdown("#### Próximas Execuções:")
                
                for job_info in jobs_status:
                    col1, col2 = st.columns([2, 1])
                    
                    with col1:
                        st.markdown(f"**{job_info['name']}**")
                    
                    with col2:
                        st.markdown(f"`{job_info['next_run']}`")
            else:
                st.info("Nenhum job agendado")
        else:
            st.warning("⚠️ Scheduler não está rodando. Jobs automáticos não serão executados.")
            
            if st.button("▶️ Iniciar Scheduler"):
                scheduler.start()
                st.success("✅ Scheduler iniciado!")
                st.rerun()
    
    except Exception as e:
        st.error(f"❌ Erro ao verificar scheduler: {e}")
    
    st.markdown("---")
    
    # Backup
    st.subheader("💾 Backup do Banco de Dados")
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.markdown("""
            Faça backup regular do banco de dados para evitar perda de dados.
            
            O backup cria uma cópia do arquivo SQLite na pasta `data/backups/`.
            Backups antigos (>7 dias) são automaticamente removidos.
        """)
    
    with col2:
        if st.button("💾 Fazer Backup Agora", use_container_width=True):
            with st.spinner("Criando backup..."):
                try:
                    import subprocess
                    import sys
                    
                    result = subprocess.run(
                        [sys.executable, "scripts/backup.py"],
                        capture_output=True,
                        text=True,
                        cwd="/home/claude/analise-acoes-mvp"
                    )
                    
                    if result.returncode == 0:
                        st.success("✅ Backup criado com sucesso!")
                    else:
                        st.error(f"❌ Erro ao criar backup: {result.stderr}")
                except Exception as e:
                    st.error(f"❌ Erro: {e}")
    
    # Rodapé com informações técnicas
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
            ### 🔧 Informações Técnicas
            
            **Versão:** 1.0.0  
            **Framework:** Streamlit  
            **Banco de Dados:** SQLite  
            **Scheduler:** APScheduler  
            
            **Fontes de Dados:**
            - Yahoo Finance (Cotações)
            - CVM (Fundamentalistas)
            - Banco Central (Macro)
        """)
    
    with col2:
        st.markdown("""
            ### 📚 Documentação
            
            **Comandos Úteis:**
            ```bash
            # Inicializar banco
            python scripts/init_database.py
            
            # Popular dados
            python scripts/seed_data.py
            
            # Fazer backup
            python scripts/backup.py
            
            # Executar app
            streamlit run app.py
            ```
        """)


if __name__ == "__main__":
    main()
