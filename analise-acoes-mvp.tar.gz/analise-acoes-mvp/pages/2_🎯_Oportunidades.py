"""
Página 2: Scanner de Oportunidades
Detecta e ranqueia as melhores oportunidades de compra
"""
import streamlit as st
import pandas as pd
from datetime import datetime

st.set_page_config(page_title="Oportunidades - B3", page_icon="🎯", layout="wide")

from src.database import get_session, Stock, OpportunityScore, FundamentalIndicator, StockPrice
from components.cards import score_card, stat_box
from components.charts import create_bar_chart
from src.utils.helpers import format_currency, format_percentage


def load_opportunities(min_score=60, max_results=20):
    """Carrega oportunidades (sinais BUY) ordenadas por score"""
    session = get_session()
    
    try:
        today = datetime.now().date()
        
        # Query para BUY signals
        results = session.query(
            Stock,
            OpportunityScore,
            FundamentalIndicator
        ).join(
            OpportunityScore,
            (OpportunityScore.stock_id == Stock.id) &
            (OpportunityScore.date == today) &
            (OpportunityScore.signal == 'BUY')
        ).outerjoin(
            FundamentalIndicator,
            (FundamentalIndicator.stock_id == Stock.id) &
            (FundamentalIndicator.date == today)
        ).filter(
            OpportunityScore.score >= min_score
        ).order_by(
            OpportunityScore.score.desc()
        ).limit(max_results).all()
        
        opportunities = []
        for stock, score_obj, indicator in results:
            # Buscar preço atual
            latest_price = session.query(StockPrice).filter_by(
                stock_id=stock.id
            ).order_by(StockPrice.date.desc()).first()
            
            opportunities.append({
                'stock': stock,
                'score': score_obj,
                'indicator': indicator,
                'price': latest_price.close if latest_price else None
            })
        
        return opportunities
        
    finally:
        session.close()


def load_value_traps(max_score=40, max_results=10):
    """Carrega value traps (sinais SELL) ordenadas por score"""
    session = get_session()
    
    try:
        today = datetime.now().date()
        
        results = session.query(
            Stock,
            OpportunityScore
        ).join(
            OpportunityScore,
            (OpportunityScore.stock_id == Stock.id) &
            (OpportunityScore.date == today) &
            (OpportunityScore.signal == 'SELL')
        ).filter(
            OpportunityScore.score <= max_score
        ).order_by(
            OpportunityScore.score.asc()
        ).limit(max_results).all()
        
        return [(stock, score_obj) for stock, score_obj in results]
        
    finally:
        session.close()


def main():
    st.title("🎯 Scanner de Oportunidades")
    st.markdown("Identifique as melhores oportunidades de compra baseadas em análise fundamentalista")
    
    st.markdown("---")
    
    # Configurações do scanner
    col1, col2 = st.columns([2, 2])
    
    with col1:
        min_score = st.slider(
            "🎯 Score Mínimo",
            min_value=50,
            max_value=100,
            value=60,
            step=5,
            help="Filtrar apenas ações com score acima deste valor"
        )
    
    with col2:
        max_results = st.slider(
            "📊 Máximo de Resultados",
            min_value=5,
            max_value=50,
            value=20,
            step=5
        )
    
    st.markdown("---")
    
    # Carregar oportunidades
    with st.spinner("🔍 Escaneando mercado..."):
        opportunities = load_opportunities(min_score, max_results)
        value_traps = load_value_traps(max_score=40, max_results=10)
    
    # Estatísticas
    col1, col2, col3 = st.columns(3)
    
    with col1:
        stat_box(
            "Oportunidades Encontradas",
            str(len(opportunities)),
            "🚀",
            "#10B981"
        )
    
    with col2:
        if opportunities:
            avg_score = sum(opp['score'].score for opp in opportunities) / len(opportunities)
            stat_box(
                "Score Médio",
                f"{avg_score:.1f}/100",
                "📊",
                "#1E40AF"
            )
        else:
            stat_box("Score Médio", "N/A", "📊", "#6B7280")
    
    with col3:
        stat_box(
            "Value Traps Detectadas",
            str(len(value_traps)),
            "⚠️",
            "#EF4444"
        )
    
    st.markdown("---")
    
    # Seção de Oportunidades (BUY)
    st.subheader("🚀 Top Oportunidades de Compra")
    
    if not opportunities:
        st.info(f"💡 Nenhuma oportunidade encontrada com score ≥ {min_score}. Tente diminuir o score mínimo.")
    else:
        # Criar tabs para diferentes visualizações
        tab1, tab2 = st.tabs(["📋 Lista Detalhada", "📊 Visão Geral"])
        
        with tab1:
            # Mostrar cada oportunidade em detalhe
            for i, opp in enumerate(opportunities[:10], 1):
                stock = opp['stock']
                score_obj = opp['score']
                indicator = opp['indicator']
                price = opp['price']
                
                with st.expander(f"#{i} - {stock.ticker} - {stock.company_name[:40]}... (Score: {score_obj.score}/100)"):
                    col1, col2 = st.columns([2, 1])
                    
                    with col1:
                        # Score card
                        score_card(
                            score=score_obj.score,
                            signal=score_obj.signal,
                            reasoning=score_obj.reasoning
                        )
                        
                        # Informações básicas
                        st.markdown(f"""
                            **Setor:** {stock.sector}  
                            **Subsetor:** {stock.subsector}  
                            **Preço Atual:** {format_currency(price) if price else 'N/A'}
                        """)
                    
                    with col2:
                        if indicator:
                            st.markdown("#### 📊 Indicadores")
                            st.markdown(f"""
                                **P/L:** {indicator.price_earnings:.2f if indicator.price_earnings else 'N/A'}  
                                **P/VP:** {indicator.price_book:.2f if indicator.price_book else 'N/A'}  
                                **ROE:** {format_percentage(indicator.roe)}  
                                **Margem Líq.:** {format_percentage(indicator.net_margin)}  
                                **Div. Yield:** {format_percentage(indicator.dividend_yield)}
                            """)
        
        with tab2:
            # Gráfico de distribuição de scores
            scores_df = pd.DataFrame({
                'Ticker': [opp['stock'].ticker for opp in opportunities],
                'Score': [opp['score'].score for opp in opportunities]
            })
            
            fig = create_bar_chart(
                scores_df.head(20),
                'Ticker',
                'Score',
                'Top 20 Oportunidades por Score'
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Tabela resumida
            st.markdown("#### 📋 Tabela Resumida")
            
            summary_data = []
            for opp in opportunities:
                summary_data.append({
                    'Ticker': opp['stock'].ticker,
                    'Empresa': opp['stock'].company_name[:30] + '...' if len(opp['stock'].company_name) > 30 else opp['stock'].company_name,
                    'Score': opp['score'].score,
                    'Preço': opp['price'],
                    'P/L': opp['indicator'].price_earnings if opp['indicator'] else None,
                    'ROE': opp['indicator'].roe * 100 if opp['indicator'] and opp['indicator'].roe else None
                })
            
            summary_df = pd.DataFrame(summary_data)
            
            st.dataframe(
                summary_df,
                column_config={
                    'Score': st.column_config.ProgressColumn(
                        'Score',
                        min_value=0,
                        max_value=100,
                        format='%d'
                    ),
                    'Preço': st.column_config.NumberColumn('Preço', format='R$ %.2f'),
                    'P/L': st.column_config.NumberColumn('P/L', format='%.2f'),
                    'ROE': st.column_config.NumberColumn('ROE', format='%.2f%%')
                },
                use_container_width=True,
                hide_index=True
            )
    
    st.markdown("---")
    
    # Seção de Value Traps (SELL)
    st.subheader("⚠️ Value Traps - Evitar")
    
    if not value_traps:
        st.success("✅ Nenhum value trap crítico detectado!")
    else:
        st.warning(f"⚠️ {len(value_traps)} ações com sinais de alerta")
        
        trap_data = []
        for stock, score_obj in value_traps:
            trap_data.append({
                'Ticker': stock.ticker,
                'Empresa': stock.company_name[:30] + '...' if len(stock.company_name) > 30 else stock.company_name,
                'Score': score_obj.score,
                'Alerta': score_obj.reasoning
            })
        
        trap_df = pd.DataFrame(trap_data)
        
        st.dataframe(
            trap_df,
            column_config={
                'Score': st.column_config.ProgressColumn(
                    'Score',
                    min_value=0,
                    max_value=100,
                    format='%d'
                )
            },
            use_container_width=True,
            hide_index=True
        )
    
    # Rodapé
    st.markdown("---")
    st.markdown("""
        💡 **Como Interpretar:**
        
        - **Score 70-100:** Forte oportunidade - Divergência favorável entre preço e fundamentos
        - **Score 40-69:** Neutro - Aguardar confirmação
        - **Score 0-39:** Cuidado - Possível value trap (preço alto vs fundamentos fracos)
        
        ⚠️ **Importante:** Esta análise é automatizada e deve ser complementada com sua própria pesquisa.
    """)


if __name__ == "__main__":
    main()
