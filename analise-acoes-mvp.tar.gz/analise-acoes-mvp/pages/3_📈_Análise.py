"""
Página 3: Análise Detalhada
Análise profunda de uma ação específica
"""
import streamlit as st
import pandas as pd
from datetime import datetime, timedelta

st.set_page_config(page_title="Análise - B3", page_icon="📈", layout="wide")

from src.database import get_session, Stock, StockPrice, FundamentalIndicator, OpportunityScore, FinancialStatement
from components.charts import create_dual_axis_chart, create_price_chart, create_gauge_chart
from components.cards import score_card, metric_card
from components.tables import format_indicators_table
from src.utils.helpers import format_currency, format_percentage


def get_stock_list():
    """Retorna lista de tickers disponíveis"""
    session = get_session()
    try:
        stocks = session.query(Stock.ticker, Stock.company_name).order_by(Stock.ticker).all()
        return {f"{s.ticker} - {s.company_name}": s.ticker for s in stocks}
    finally:
        session.close()


def load_stock_analysis(ticker):
    """Carrega análise completa de uma ação"""
    session = get_session()
    
    try:
        # Stock info
        stock = session.query(Stock).filter_by(ticker=ticker).first()
        if not stock:
            return None
        
        today = datetime.now().date()
        
        # Score mais recente
        latest_score = session.query(OpportunityScore).filter_by(
            stock_id=stock.id,
            date=today
        ).first()
        
        # Indicadores
        latest_indicator = session.query(FundamentalIndicator).filter_by(
            stock_id=stock.id,
            date=today
        ).first()
        
        # Preços (últimos 2 anos)
        two_years_ago = today - timedelta(days=730)
        prices = session.query(StockPrice).filter(
            StockPrice.stock_id == stock.id,
            StockPrice.date >= two_years_ago
        ).order_by(StockPrice.date).all()
        
        # Demonstrativos financeiros
        financials = session.query(FinancialStatement).filter_by(
            stock_id=stock.id
        ).order_by(FinancialStatement.period.desc()).limit(20).all()
        
        return {
            'stock': stock,
            'score': latest_score,
            'indicator': latest_indicator,
            'prices': prices,
            'financials': financials
        }
        
    finally:
        session.close()


def main():
    st.title("📈 Análise Detalhada")
    st.markdown("Análise completa de uma ação específica")
    
    st.markdown("---")
    
    # Seletor de ação
    stock_options = get_stock_list()
    
    if not stock_options:
        st.error("❌ Nenhuma ação encontrada no banco de dados!")
        st.info("Execute: python scripts/seed_data.py")
        return
    
    selected = st.selectbox(
        "🔍 Selecione uma Ação",
        options=list(stock_options.keys()),
        index=0
    )
    
    ticker = stock_options[selected]
    
    # Carregar análise
    with st.spinner(f"Carregando análise de {ticker}..."):
        data = load_stock_analysis(ticker)
    
    if not data:
        st.error(f"❌ Ação {ticker} não encontrada!")
        return
    
    stock = data['stock']
    score = data['score']
    indicator = data['indicator']
    prices = data['prices']
    financials = data['financials']
    
    # Header da ação
    st.header(f"{stock.ticker} - {stock.company_name}")
    
    col1, col2, col3 = st.columns([1, 1, 1])
    
    with col1:
        st.markdown(f"**Setor:** {stock.sector}")
    with col2:
        st.markdown(f"**Subsetor:** {stock.subsector}")
    with col3:
        if prices:
            latest_price = prices[-1].close
            st.markdown(f"**Preço Atual:** {format_currency(latest_price)}")
    
    st.markdown("---")
    
    # Score e Indicadores
    col1, col2 = st.columns([1, 2])
    
    with col1:
        if score:
            # Score gauge
            st.subheader("🎯 Score de Oportunidade")
            fig_gauge = create_gauge_chart(score.score, "Score")
            st.plotly_chart(fig_gauge, use_container_width=True)
            
            # Score card
            score_card(
                score=score.score,
                signal=score.signal,
                reasoning=score.reasoning
            )
        else:
            st.info("Score ainda não calculado para esta ação")
    
    with col2:
        if indicator:
            st.subheader("📊 Indicadores Fundamentalistas")
            
            # Métricas em colunas
            metric_col1, metric_col2, metric_col3 = st.columns(3)
            
            with metric_col1:
                st.metric("P/L", f"{indicator.price_earnings:.2f}" if indicator.price_earnings else "N/A")
                st.metric("ROE", format_percentage(indicator.roe))
            
            with metric_col2:
                st.metric("P/VP", f"{indicator.price_book:.2f}" if indicator.price_book else "N/A")
                st.metric("ROA", format_percentage(indicator.roa))
            
            with metric_col3:
                st.metric("Dívida/PL", f"{indicator.debt_equity:.2f}" if indicator.debt_equity else "N/A")
                st.metric("DY", format_percentage(indicator.dividend_yield))
            
            # Tabela de indicadores
            st.markdown("---")
            indicators_dict = {
                'price_earnings': indicator.price_earnings,
                'price_book': indicator.price_book,
                'roe': indicator.roe,
                'roa': indicator.roa,
                'net_margin': indicator.net_margin,
                'debt_equity': indicator.debt_equity,
                'dividend_yield': indicator.dividend_yield
            }
            
            ind_table = format_indicators_table(indicators_dict)
            st.dataframe(ind_table, use_container_width=True, hide_index=True)
        else:
            st.info("Indicadores ainda não calculados")
    
    st.markdown("---")
    
    # Gráficos
    if prices and len(prices) > 0:
        st.subheader("📈 Análise de Preço e Fundamentos")
        
        # Preparar dados
        prices_df = pd.DataFrame([{
            'date': p.date,
            'close': p.close,
            'open': p.open,
            'high': p.high,
            'low': p.low,
            'volume': p.volume
        } for p in prices])
        
        # Tab para diferentes gráficos
        tab1, tab2 = st.tabs(["💹 Evolução do Preço", "🔄 Preço vs Lucros"])
        
        with tab1:
            # Gráfico de preço simples
            fig_price = create_price_chart(
                prices_df,
                f"Evolução do Preço - {ticker}"
            )
            st.plotly_chart(fig_price, use_container_width=True)
            
            # Estatísticas de preço
            col1, col2, col3, col4 = st.columns(4)
            
            current_price = prices_df['close'].iloc[-1]
            min_price = prices_df['close'].min()
            max_price = prices_df['close'].max()
            avg_price = prices_df['close'].mean()
            
            with col1:
                st.metric("Preço Atual", format_currency(current_price))
            with col2:
                st.metric("Mínimo (2 anos)", format_currency(min_price))
            with col3:
                st.metric("Máximo (2 anos)", format_currency(max_price))
            with col4:
                st.metric("Média (2 anos)", format_currency(avg_price))
        
        with tab2:
            if financials and len(financials) > 0:
                # Preparar dados de lucros
                financials_df = pd.DataFrame([{
                    'date': f.period,
                    'net_income': f.net_income / 1_000_000  # Converter para milhões
                } for f in reversed(financials)])
                
                # Combinar preços e lucros por trimestre
                # Simplificado: agrupar preços por trimestre
                prices_df['quarter'] = pd.to_datetime(prices_df['date']).dt.to_period('Q')
                quarterly_prices = prices_df.groupby('quarter')['close'].mean().reset_index()
                quarterly_prices['date'] = quarterly_prices['quarter'].dt.to_timestamp()
                
                # Merge com financials
                financials_df['quarter'] = pd.to_datetime(financials_df['date']).dt.to_period('Q')
                
                merged_df = pd.merge(
                    quarterly_prices[['date', 'close']],
                    financials_df[['date', 'net_income']],
                    on='date',
                    how='inner'
                )
                
                if not merged_df.empty:
                    fig_dual = create_dual_axis_chart(
                        merged_df,
                        'close',
                        'net_income',
                        'Preço',
                        'Lucro Líquido',
                        f'{ticker} - Preço vs Lucro Líquido'
                    )
                    st.plotly_chart(fig_dual, use_container_width=True)
                    
                    st.info("💡 Este gráfico mostra a divergência entre preço e fundamentos. Quando o preço cai mas o lucro sobe, pode indicar oportunidade.")
                else:
                    st.warning("Dados insuficientes para gerar gráfico de divergência")
            else:
                st.info("Dados financeiros não disponíveis")
    else:
        st.warning("⚠️ Dados de preços não disponíveis")
    
    st.markdown("---")
    
    # Demonstrativos Financeiros
    if financials:
        st.subheader("💼 Demonstrativos Financeiros (Últimos 5 Anos)")
        
        fin_data = []
        for f in reversed(financials[-20:]):  # Últimos 20 trimestres
            fin_data.append({
                'Período': f.period.strftime('%m/%Y'),
                'Receita (M)': f.revenue / 1_000_000 if f.revenue else 0,
                'Lucro Líq. (M)': f.net_income / 1_000_000 if f.net_income else 0,
                'EBITDA (M)': f.ebitda / 1_000_000 if f.ebitda else 0,
                'Margem Líq. (%)': (f.net_income / f.revenue * 100) if f.revenue and f.net_income else 0
            })
        
        fin_df = pd.DataFrame(fin_data)
        
        st.dataframe(
            fin_df,
            column_config={
                'Receita (M)': st.column_config.NumberColumn('Receita (M)', format='%.2f'),
                'Lucro Líq. (M)': st.column_config.NumberColumn('Lucro (M)', format='%.2f'),
                'EBITDA (M)': st.column_config.NumberColumn('EBITDA (M)', format='%.2f'),
                'Margem Líq. (%)': st.column_config.NumberColumn('Margem %', format='%.2f%%')
            },
            use_container_width=True,
            hide_index=True
        )
    
    # Rodapé
    st.markdown("---")
    st.markdown("""
        💡 **Sobre esta Análise:**
        
        - Dados atualizados diariamente às 19h (preços) e 20h (scores)
        - Fundamentalistas atualizados semanalmente (Domingos 2h)
        - Score baseado em divergência preço/fundamentos, qualidade fundamentalista e momentum
        
        ⚠️ **Importante:** Use esta análise como ponto de partida. Sempre faça sua própria pesquisa.
    """)


if __name__ == "__main__":
    main()
