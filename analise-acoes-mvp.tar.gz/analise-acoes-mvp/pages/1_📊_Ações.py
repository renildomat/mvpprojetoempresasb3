"""
Página 1: Listagem de Ações
Mostra todas as ações com filtros e ordenação
"""
import streamlit as st
import pandas as pd
from datetime import datetime

st.set_page_config(page_title="Ações - B3", page_icon="📊", layout="wide")

from src.database import get_session, Stock, StockPrice, FundamentalIndicator, OpportunityScore
from components.tables import create_stocks_table
from src.utils.helpers import format_currency, format_percentage


def load_stocks_data(sector_filter=None, signal_filter=None):
    """Carrega dados das ações com filtros"""
    session = get_session()
    
    try:
        today = datetime.now().date()
        
        # Query base
        query = session.query(
            Stock.ticker,
            Stock.company_name,
            Stock.sector,
            Stock.subsector,
            OpportunityScore.score,
            OpportunityScore.signal,
            FundamentalIndicator.price_earnings,
            FundamentalIndicator.price_book,
            FundamentalIndicator.roe,
            FundamentalIndicator.dividend_yield
        ).outerjoin(
            OpportunityScore,
            (OpportunityScore.stock_id == Stock.id) &
            (OpportunityScore.date == today)
        ).outerjoin(
            FundamentalIndicator,
            (FundamentalIndicator.stock_id == Stock.id) &
            (FundamentalIndicator.date == today)
        )
        
        # Aplicar filtros
        if sector_filter and sector_filter != "Todos":
            query = query.filter(Stock.sector == sector_filter)
        
        if signal_filter and signal_filter != "Todos":
            query = query.filter(OpportunityScore.signal == signal_filter)
        
        # Executar query
        results = query.all()
        
        # Converter para DataFrame
        data = []
        for r in results:
            data.append({
                'ticker': r.ticker,
                'company_name': r.company_name,
                'sector': r.sector or 'N/A',
                'subsector': r.subsector or 'N/A',
                'score': r.score if r.score is not None else 0,
                'signal': r.signal or 'N/A',
                'price_earnings': r.price_earnings,
                'price_book': r.price_book,
                'roe': r.roe * 100 if r.roe else None,
                'dividend_yield': r.dividend_yield * 100 if r.dividend_yield else None
            })
        
        # Buscar preço atual para cada ação
        for item in data:
            latest_price = session.query(StockPrice).join(Stock).filter(
                Stock.ticker == item['ticker']
            ).order_by(StockPrice.date.desc()).first()
            
            item['close'] = latest_price.close if latest_price else None
        
        return pd.DataFrame(data)
        
    finally:
        session.close()


def get_sectors():
    """Retorna lista de setores"""
    session = get_session()
    try:
        sectors = session.query(Stock.sector).distinct().all()
        return ["Todos"] + [s[0] for s in sectors if s[0]]
    finally:
        session.close()


def main():
    st.title("📊 Listagem de Ações")
    st.markdown("Visualize todas as ações monitoradas com filtros e ordenação")
    
    st.markdown("---")
    
    # Filtros
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        sectors = get_sectors()
        sector_filter = st.selectbox(
            "🏢 Filtrar por Setor",
            sectors
        )
    
    with col2:
        signal_filter = st.selectbox(
            "🎯 Filtrar por Sinal",
            ["Todos", "BUY", "HOLD", "SELL"]
        )
    
    with col3:
        sort_by = st.selectbox(
            "📊 Ordenar por",
            ["Score (maior)", "Score (menor)", "Ticker A-Z", "Ticker Z-A"]
        )
    
    # Carregar dados
    with st.spinner("Carregando dados..."):
        df = load_stocks_data(sector_filter, signal_filter)
    
    if df.empty:
        st.warning("⚠️ Nenhuma ação encontrada com os filtros selecionados.")
        st.info("💡 Tente remover alguns filtros ou execute 'python scripts/seed_data.py'")
        return
    
    # Aplicar ordenação
    if sort_by == "Score (maior)":
        df = df.sort_values('score', ascending=False)
    elif sort_by == "Score (menor)":
        df = df.sort_values('score', ascending=True)
    elif sort_by == "Ticker A-Z":
        df = df.sort_values('ticker', ascending=True)
    elif sort_by == "Ticker Z-A":
        df = df.sort_values('ticker', ascending=False)
    
    # Estatísticas rápidas
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total de Ações", len(df))
    
    with col2:
        avg_score = df['score'].mean()
        st.metric("Score Médio", f"{avg_score:.1f}")
    
    with col3:
        buy_count = len(df[df['signal'] == 'BUY'])
        st.metric("Oportunidades (BUY)", buy_count)
    
    with col4:
        sell_count = len(df[df['signal'] == 'SELL'])
        st.metric("Alertas (SELL)", sell_count)
    
    st.markdown("---")
    
    # Tabela principal
    st.subheader(f"📋 {len(df)} Ações Encontradas")
    
    # Renomear colunas para exibição
    display_df = df.rename(columns={
        'ticker': 'Ticker',
        'company_name': 'Empresa',
        'sector': 'Setor',
        'score': 'Score',
        'signal': 'Sinal',
        'close': 'Preço',
        'price_earnings': 'P/L',
        'price_book': 'P/VP',
        'roe': 'ROE (%)',
        'dividend_yield': 'DY (%)'
    })
    
    # Selecionar colunas para exibição
    cols_to_show = ['Ticker', 'Empresa', 'Setor', 'Score', 'Sinal', 'Preço', 'P/L', 'ROE (%)', 'DY (%)']
    display_df = display_df[cols_to_show]
    
    # Configurar colunas
    column_config = {
        'Ticker': st.column_config.TextColumn('Ticker', width='small'),
        'Empresa': st.column_config.TextColumn('Empresa', width='large'),
        'Setor': st.column_config.TextColumn('Setor', width='medium'),
        'Score': st.column_config.ProgressColumn(
            'Score',
            min_value=0,
            max_value=100,
            format='%d',
            width='small'
        ),
        'Sinal': st.column_config.TextColumn('Sinal', width='small'),
        'Preço': st.column_config.NumberColumn(
            'Preço',
            format='R$ %.2f',
            width='small'
        ),
        'P/L': st.column_config.NumberColumn('P/L', format='%.2f', width='small'),
        'ROE (%)': st.column_config.NumberColumn('ROE', format='%.2f%%', width='small'),
        'DY (%)': st.column_config.NumberColumn('DY', format='%.2f%%', width='small')
    }
    
    # Mostrar tabela com seleção
    selected_rows = st.dataframe(
        display_df,
        column_config=column_config,
        use_container_width=True,
        hide_index=True,
        height=600
    )
    
    # Opções de exportação
    st.markdown("---")
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.markdown("💡 **Dica:** Clique no ticker de uma ação para ver análise detalhada na página 'Análise Detalhada'")
    
    with col2:
        # Botão de download
        csv = display_df.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="📥 Exportar CSV",
            data=csv,
            file_name=f"acoes_b3_{datetime.now().strftime('%Y%m%d')}.csv",
            mime="text/csv"
        )


if __name__ == "__main__":
    main()
