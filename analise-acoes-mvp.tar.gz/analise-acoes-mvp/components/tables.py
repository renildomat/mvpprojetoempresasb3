"""
Componentes de tabelas interativas
"""
import streamlit as st
import pandas as pd
from typing import List, Dict, Optional
from src.utils.helpers import format_currency, format_percentage, get_color_for_value


def create_stocks_table(df: pd.DataFrame, height: int = 600) -> None:
    """
    Cria tabela interativa de ações com formatação
    
    Args:
        df: DataFrame com dados das ações
        height: Altura da tabela em pixels
    """
    # Configurar colunas formatadas
    columns_config = {
        'ticker': st.column_config.TextColumn('Ticker', width='small'),
        'company_name': st.column_config.TextColumn('Empresa', width='large'),
        'sector': st.column_config.TextColumn('Setor', width='medium'),
        'score': st.column_config.ProgressColumn(
            'Score',
            min_value=0,
            max_value=100,
            format='%d',
            width='small'
        ),
        'signal': st.column_config.TextColumn('Sinal', width='small'),
        'close': st.column_config.NumberColumn(
            'Preço',
            format='R$ %.2f',
            width='small'
        ),
        'price_earnings': st.column_config.NumberColumn(
            'P/L',
            format='%.2f',
            width='small'
        ),
        'roe': st.column_config.NumberColumn(
            'ROE',
            format='%.2f%%',
            width='small'
        ),
        'dividend_yield': st.column_config.NumberColumn(
            'DY',
            format='%.2f%%',
            width='small'
        )
    }
    
    # Mostrar tabela
    st.dataframe(
        df,
        column_config=columns_config,
        use_container_width=True,
        height=height,
        hide_index=True
    )


def format_indicators_table(indicators: Dict) -> pd.DataFrame:
    """
    Formata indicadores como tabela para exibição
    
    Args:
        indicators: Dicionário com indicadores
    
    Returns:
        DataFrame formatado
    """
    data = []
    
    # Mapeamento de indicadores
    indicator_map = {
        'price_earnings': ('P/L', lambda x: f"{x:.2f}" if x else "N/A"),
        'price_book': ('P/VP', lambda x: f"{x:.2f}" if x else "N/A"),
        'roe': ('ROE', lambda x: format_percentage(x)),
        'roa': ('ROA', lambda x: format_percentage(x)),
        'net_margin': ('Margem Líquida', lambda x: format_percentage(x)),
        'debt_equity': ('Dívida/PL', lambda x: f"{x:.2f}" if x else "N/A"),
        'dividend_yield': ('Dividend Yield', lambda x: format_percentage(x))
    }
    
    for key, (name, formatter) in indicator_map.items():
        value = indicators.get(key)
        data.append({
            'Indicador': name,
            'Valor': formatter(value) if value is not None else "N/A"
        })
    
    return pd.DataFrame(data)


def create_compact_table(data: List[Dict], columns: List[str]) -> pd.DataFrame:
    """
    Cria tabela compacta a partir de lista de dicionários
    
    Args:
        data: Lista de dicionários
        columns: Colunas a exibir
    
    Returns:
        DataFrame formatado
    """
    if not data:
        return pd.DataFrame()
    
    df = pd.DataFrame(data)
    
    # Selecionar apenas colunas especificadas
    if columns:
        df = df[[col for col in columns if col in df.columns]]
    
    return df


def create_comparison_table(stocks_data: List[Dict]) -> pd.DataFrame:
    """
    Cria tabela de comparação entre ações
    
    Args:
        stocks_data: Lista de dicionários com dados das ações
    
    Returns:
        DataFrame formatado para comparação
    """
    if not stocks_data:
        return pd.DataFrame()
    
    df = pd.DataFrame(stocks_data)
    
    # Selecionar colunas relevantes
    comparison_cols = [
        'ticker', 'score', 'signal', 'price_earnings',
        'roe', 'net_margin', 'dividend_yield'
    ]
    
    df = df[[col for col in comparison_cols if col in df.columns]]
    
    return df


def highlight_signal(val):
    """
    Aplica cor baseada no sinal (BUY/SELL/HOLD)
    Usado com DataFrame.style.applymap()
    """
    if val == 'BUY':
        return 'background-color: #D1FAE5; color: #065F46'
    elif val == 'SELL':
        return 'background-color: #FEE2E2; color: #991B1B'
    elif val == 'HOLD':
        return 'background-color: #FEF3C7; color: #92400E'
    return ''


def highlight_score(val):
    """
    Aplica cor baseada no score (0-100)
    """
    try:
        val = float(val)
        if val >= 70:
            return 'background-color: #D1FAE5; color: #065F46'
        elif val >= 40:
            return 'background-color: #FEF3C7; color: #92400E'
        else:
            return 'background-color: #FEE2E2; color: #991B1B'
    except:
        return ''
