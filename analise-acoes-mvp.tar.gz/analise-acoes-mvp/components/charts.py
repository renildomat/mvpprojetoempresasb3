"""
Componentes de gráficos usando Plotly
"""
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from typing import List, Optional


def create_price_chart(prices_df: pd.DataFrame, title: str = "Evolução do Preço") -> go.Figure:
    """
    Cria gráfico de linha de preços
    
    Args:
        prices_df: DataFrame com colunas ['date', 'close']
        title: Título do gráfico
    
    Returns:
        Figura Plotly
    """
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=prices_df['date'],
        y=prices_df['close'],
        mode='lines',
        name='Preço',
        line=dict(color='#1E40AF', width=2),
        fill='tozeroy',
        fillcolor='rgba(30, 64, 175, 0.1)'
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title="Data",
        yaxis_title="Preço (R$)",
        hovermode='x unified',
        template='plotly_white',
        height=400,
        margin=dict(l=50, r=50, t=50, b=50)
    )
    
    return fig


def create_dual_axis_chart(
    df: pd.DataFrame,
    y1_col: str,
    y2_col: str,
    y1_name: str = "Preço",
    y2_name: str = "Lucro",
    title: str = "Preço vs Fundamentos"
) -> go.Figure:
    """
    Cria gráfico com dois eixos Y (preço e fundamentos)
    
    Args:
        df: DataFrame com colunas ['date', y1_col, y2_col]
        y1_col: Coluna do eixo Y esquerdo (preço)
        y2_col: Coluna do eixo Y direito (lucro)
        y1_name: Nome da série 1
        y2_name: Nome da série 2
        title: Título do gráfico
    
    Returns:
        Figura Plotly
    """
    fig = go.Figure()
    
    # Linha de preço (eixo esquerdo)
    fig.add_trace(go.Scatter(
        x=df['date'],
        y=df[y1_col],
        name=y1_name,
        line=dict(color='#1E40AF', width=2),
        yaxis='y1'
    ))
    
    # Linha de lucro (eixo direito)
    fig.add_trace(go.Scatter(
        x=df['date'],
        y=df[y2_col],
        name=y2_name,
        line=dict(color='#10B981', width=2),
        yaxis='y2'
    ))
    
    # Layout com dois eixos
    fig.update_layout(
        title=title,
        xaxis=dict(title="Data"),
        yaxis=dict(
            title=f"{y1_name} (R$)",
            titlefont=dict(color='#1E40AF'),
            tickfont=dict(color='#1E40AF')
        ),
        yaxis2=dict(
            title=f"{y2_name} (R$ M)",
            titlefont=dict(color='#10B981'),
            tickfont=dict(color='#10B981'),
            anchor='x',
            overlaying='y',
            side='right'
        ),
        hovermode='x unified',
        template='plotly_white',
        height=500,
        legend=dict(x=0.01, y=0.99, bgcolor='rgba(255,255,255,0.8)')
    )
    
    return fig


def create_bar_chart(
    df: pd.DataFrame,
    x_col: str,
    y_col: str,
    title: str = "Gráfico de Barras",
    color_col: Optional[str] = None
) -> go.Figure:
    """
    Cria gráfico de barras
    
    Args:
        df: DataFrame com dados
        x_col: Coluna do eixo X
        y_col: Coluna do eixo Y
        title: Título
        color_col: Coluna para colorir barras (opcional)
    
    Returns:
        Figura Plotly
    """
    if color_col:
        colors = df[color_col].apply(lambda x: '#10B981' if x > 0 else '#EF4444')
    else:
        colors = '#1E40AF'
    
    fig = go.Figure(data=[
        go.Bar(
            x=df[x_col],
            y=df[y_col],
            marker_color=colors
        )
    ])
    
    fig.update_layout(
        title=title,
        xaxis_title=x_col.replace('_', ' ').title(),
        yaxis_title=y_col.replace('_', ' ').title(),
        template='plotly_white',
        height=400
    )
    
    return fig


def create_gauge_chart(value: float, title: str = "Score") -> go.Figure:
    """
    Cria gráfico de gauge (medidor) para score
    
    Args:
        value: Valor do score (0-100)
        title: Título
    
    Returns:
        Figura Plotly
    """
    # Definir cor baseada no valor
    if value >= 70:
        color = '#10B981'  # Verde
    elif value >= 40:
        color = '#F59E0B'  # Laranja
    else:
        color = '#EF4444'  # Vermelho
    
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=value,
        title={'text': title, 'font': {'size': 24}},
        gauge={
            'axis': {'range': [None, 100], 'tickwidth': 1},
            'bar': {'color': color},
            'steps': [
                {'range': [0, 35], 'color': "#FEE2E2"},
                {'range': [35, 70], 'color': "#FEF3C7"},
                {'range': [70, 100], 'color': "#D1FAE5"}
            ],
            'threshold': {
                'line': {'color': "black", 'width': 4},
                'thickness': 0.75,
                'value': value
            }
        }
    ))
    
    fig.update_layout(
        height=300,
        margin=dict(l=20, r=20, t=50, b=20)
    )
    
    return fig


def create_candlestick_chart(df: pd.DataFrame, title: str = "Candlestick") -> go.Figure:
    """
    Cria gráfico de candlestick
    
    Args:
        df: DataFrame com colunas ['date', 'open', 'high', 'low', 'close']
        title: Título
    
    Returns:
        Figura Plotly
    """
    fig = go.Figure(data=[go.Candlestick(
        x=df['date'],
        open=df['open'],
        high=df['high'],
        low=df['low'],
        close=df['close'],
        increasing_line_color='#10B981',
        decreasing_line_color='#EF4444'
    )])
    
    fig.update_layout(
        title=title,
        xaxis_title="Data",
        yaxis_title="Preço (R$)",
        template='plotly_white',
        height=500,
        xaxis_rangeslider_visible=False
    )
    
    return fig
