"""
Componentes de cards e métricas visuais
"""
import streamlit as st
from typing import Optional
from src.utils.helpers import format_currency, format_percentage, get_color_for_value, get_score_badge


def metric_card(label: str, value: str, delta: Optional[str] = None, delta_color: str = "normal"):
    """
    Cria card de métrica usando st.metric nativo
    
    Args:
        label: Rótulo da métrica
        value: Valor principal
        delta: Variação (opcional)
        delta_color: "normal", "inverse", ou "off"
    """
    st.metric(
        label=label,
        value=value,
        delta=delta,
        delta_color=delta_color
    )


def score_card(score: float, signal: str, reasoning: str):
    """
    Card especial para exibir score de oportunidade
    
    Args:
        score: Score 0-100
        signal: 'BUY', 'SELL', ou 'HOLD'
        reasoning: Explicação do score
    """
    badge = get_score_badge(score)
    
    # Container com borda colorida
    st.markdown(f"""
        <div style="
            border: 3px solid {badge['color']};
            border-radius: 10px;
            padding: 20px;
            background: white;
            margin: 10px 0;
        ">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h2 style="margin: 0; color: #111827;">
                        {badge['emoji']} Score: {score:.0f}/100
                    </h2>
                    <p style="
                        margin: 5px 0 0 0;
                        font-size: 18px;
                        font-weight: bold;
                        color: {badge['color']};
                    ">
                        {badge['label']}
                    </p>
                </div>
                <div style="
                    background: {badge['color']};
                    color: white;
                    padding: 15px 25px;
                    border-radius: 8px;
                    font-size: 24px;
                    font-weight: bold;
                ">
                    {signal}
                </div>
            </div>
            <p style="margin: 15px 0 0 0; color: #6B7280; font-size: 14px;">
                {reasoning}
            </p>
        </div>
    """, unsafe_allow_html=True)


def info_card(title: str, content: str, icon: str = "ℹ️"):
    """
    Card informativo simples
    
    Args:
        title: Título do card
        content: Conteúdo/texto
        icon: Emoji/ícone
    """
    st.markdown(f"""
        <div style="
            background: #F9FAFB;
            border-left: 4px solid #1E40AF;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        ">
            <h4 style="margin: 0 0 10px 0; color: #1E40AF;">
                {icon} {title}
            </h4>
            <p style="margin: 0; color: #4B5563;">
                {content}
            </p>
        </div>
    """, unsafe_allow_html=True)


def alert_card(message: str, alert_type: str = "info"):
    """
    Card de alerta/aviso
    
    Args:
        message: Mensagem do alerta
        alert_type: 'info', 'success', 'warning', 'error'
    """
    colors = {
        'info': {'bg': '#DBEAFE', 'border': '#3B82F6', 'icon': 'ℹ️'},
        'success': {'bg': '#D1FAE5', 'border': '#10B981', 'icon': '✅'},
        'warning': {'bg': '#FEF3C7', 'border': '#F59E0B', 'icon': '⚠️'},
        'error': {'bg': '#FEE2E2', 'border': '#EF4444', 'icon': '❌'}
    }
    
    config = colors.get(alert_type, colors['info'])
    
    st.markdown(f"""
        <div style="
            background: {config['bg']};
            border-left: 4px solid {config['border']};
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        ">
            <p style="margin: 0; color: #111827;">
                {config['icon']} {message}
            </p>
        </div>
    """, unsafe_allow_html=True)


def stat_box(label: str, value: str, icon: str = "", color: str = "#1E40AF"):
    """
    Box de estatística simples
    
    Args:
        label: Rótulo
        value: Valor
        icon: Emoji/ícone (opcional)
        color: Cor do tema
    """
    st.markdown(f"""
        <div style="
            background: linear-gradient(135deg, {color} 0%, {color}DD 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        ">
            <div style="font-size: 32px; margin-bottom: 5px;">
                {icon}
            </div>
            <div style="font-size: 28px; font-weight: bold; margin-bottom: 5px;">
                {value}
            </div>
            <div style="font-size: 14px; opacity: 0.9;">
                {label}
            </div>
        </div>
    """, unsafe_allow_html=True)


def progress_bar(label: str, value: float, max_value: float = 100, color: str = "#1E40AF"):
    """
    Barra de progresso customizada
    
    Args:
        label: Rótulo
        value: Valor atual
        max_value: Valor máximo
        color: Cor da barra
    """
    percentage = min((value / max_value) * 100, 100)
    
    st.markdown(f"""
        <div style="margin: 10px 0;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                <span style="color: #4B5563; font-size: 14px;">{label}</span>
                <span style="color: #111827; font-weight: bold; font-size: 14px;">
                    {value:.1f} / {max_value:.0f}
                </span>
            </div>
            <div style="
                background: #E5E7EB;
                border-radius: 10px;
                height: 20px;
                overflow: hidden;
            ">
                <div style="
                    background: {color};
                    width: {percentage}%;
                    height: 100%;
                    border-radius: 10px;
                    transition: width 0.3s ease;
                "></div>
            </div>
        </div>
    """, unsafe_allow_html=True)


def comparison_card(ticker1: str, ticker2: str, metrics: dict):
    """
    Card de comparação entre duas ações
    
    Args:
        ticker1: Ticker da primeira ação
        ticker2: Ticker da segunda ação
        metrics: Dict com métricas {metric_name: {ticker1: value1, ticker2: value2}}
    """
    st.markdown(f"""
        <div style="
            border: 2px solid #E5E7EB;
            border-radius: 10px;
            padding: 15px;
            background: white;
        ">
            <h3 style="text-align: center; color: #111827; margin-bottom: 20px;">
                {ticker1} vs {ticker2}
            </h3>
    """, unsafe_allow_html=True)
    
    # Comparar cada métrica
    for metric_name, values in metrics.items():
        val1 = values.get(ticker1, 0)
        val2 = values.get(ticker2, 0)
        
        # Determinar vencedor
        if val1 > val2:
            color1, color2 = "#10B981", "#E5E7EB"
        elif val2 > val1:
            color1, color2 = "#E5E7EB", "#10B981"
        else:
            color1 = color2 = "#F59E0B"
        
        st.markdown(f"""
            <div style="margin: 15px 0;">
                <p style="color: #6B7280; font-size: 12px; margin-bottom: 5px;">
                    {metric_name}
                </p>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                    <div style="
                        background: {color1};
                        padding: 10px;
                        border-radius: 5px;
                        text-align: center;
                    ">
                        <strong>{val1}</strong>
                    </div>
                    <div style="
                        background: {color2};
                        padding: 10px;
                        border-radius: 5px;
                        text-align: center;
                    ">
                        <strong>{val2}</strong>
                    </div>
                </div>
            </div>
        """, unsafe_allow_html=True)
    
    st.markdown("</div>", unsafe_allow_html=True)
